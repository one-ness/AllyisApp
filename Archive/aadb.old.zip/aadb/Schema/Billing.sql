﻿CREATE SCHEMA [Billing]
