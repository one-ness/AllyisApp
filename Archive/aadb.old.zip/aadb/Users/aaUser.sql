﻿CREATE USER [aaUser]
	FOR LOGIN [aaUser]

GO

EXEC sp_addrolemember 'db_owner', 'aaUser'

GO
