﻿-- TimeTracker --
INSERT INTO [Billing].[Product] (ProductId, Name, IsActive, AreaUrl) VALUES (1, 'TimeTracker', 1, 'TimeTracker');

-- Consulting --
INSERT INTO [Billing].[Product] (ProductId, Name, IsActive, AreaUrl) VALUES (2, 'Consulting', 0, 'Consulting');
