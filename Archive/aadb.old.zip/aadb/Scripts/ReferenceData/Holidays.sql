﻿--2015
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'New Year''s Day', @Date = '01/01/2015', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Memorial Day', @Date = '05/25/2015', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Independence Day', @Date = '07/03/2015', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Labor Day', @Date = '09/07/2015', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Thanksgiving', @Date = '11/24/2015', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Day After Thanksgiving', @Date = '11/25/2015', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Christmas Eve', @Date = '12/24/2015', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Christmas', @Date = '12/25/2015', @OrganizationId = 0;

--2016
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'New Year''s Day', @Date = '01/01/2016', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Memorial Day', @Date = '05/30/2016', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Independence Day', @Date = '07/04/2016', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Labor Day', @Date = '09/05/2016', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Thanksgiving', @Date = '11/24/2016', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Day After Thanksgiving', @Date = '11/25/2016', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Christmas Eve', @Date = '12/23/2016', @OrganizationId = 0;
EXEC [TimeTracker].[CreateHoliday] @HolidayName = 'Christmas', @Date = '12/26/2016', @OrganizationId = 0;