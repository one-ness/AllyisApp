﻿INSERT INTO [TimeTracker].[PayClass] (Name, OrganizationId)
VALUES ('Regular', 0)

INSERT INTO [TimeTracker].[PayClass] (Name, OrganizationId)
VALUES ('Paid Time Off', 0)

INSERT INTO [TimeTracker].[PayClass] (Name, OrganizationId)
VALUES ('Unpaid Time Off', 0)

INSERT INTO [TimeTracker].[PayClass] (Name, OrganizationId)
VALUES ('Holiday', 0)

INSERT INTO [TimeTracker].[PayClass] (Name, OrganizationId)
VALUES ('Bereavement Leave', 0)

INSERT INTO [TimeTracker].[PayClass] (Name, OrganizationId)
VALUES ('Jury Duty', 0)

INSERT INTO [TimeTracker].[PayClass] (Name, OrganizationId)
VALUES ('Overtime', 0)

INSERT INTO [TimeTracker].[PayClass] (Name, OrganizationId)
VALUES ('Other Leave', 0)