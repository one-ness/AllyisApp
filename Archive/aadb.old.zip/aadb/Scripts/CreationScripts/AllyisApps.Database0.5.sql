USE [AllyisApps.Database] 
GO 

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Auth].[GetLast]
	@Email NVarChar(100)
AS
	
SELECT [Auth].[Organization].[Name] as Organization, Auth.Organization.OrganizationId, [Billing].[Product].[ProductId],[Billing].[Product].[Name] as Product from [Billing].[Subscription] inner join 
[Auth].[User] on [Auth].[User].[LastSubscriptionId]=[Billing].[Subscription].[SubscriptionId] inner join
[Auth].[Organization] on [auth].[Organization].[OrganizationId]=[Billing].[Subscription].[OrganizationId]  inner join 
[Billing].[SKU] on [Billing].[SKU].SKUId=[Billing].[Subscription].[SKUId] inner join
[Billing].[Product] on [Billing].[SKU].[ProductId]=[Billing].[Product].[ProductId]
where  [Email]=@Email
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE procedure Auth.GetUserOrganizationPermissions
	@userId varchar(40)
AS
BEGIN
	SELECT	[User].UserId,
			Organization.OrganizationId,
			OrgRole.OrgRoleId,
			OrgRole.Name as OrgRoleName,
			Project.ProjectId,
			Project.IsActive,
			OrgRole.PermissionAdmin
			FROM (
				(SELECT * FROM Auth.[User] WHERE UserId=@userId) as [User]
				join Auth.OrganizationUser	ON OrganizationUser.UserId=[User].UserId
				join Auth.Organization		ON OrganizationUser.OrganizationId=Organization.OrganizationId
				join Auth.OrgRole			ON OrgRole.OrgRoleId=OrganizationUser.OrgRoleId
				left join Shared.Project	ON Project.OrganizationId=Organization.OrganizationId
	) WHERE [OrganizationUser].IsActive = 1
		AND [Organization].IsActive = 1
		AND (ProjectId IS NULL OR Project.IsActive=1)
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
--DECLARE @userId varchar(40) = 'f4abe6fe-e79f-4969-818d-5a306bfc3560';
CREATE procedure [Auth].[GetUserSubscriptionPermissions]
	@userId varchar(40)
AS
BEGIN
	SELECT
	[User].UserId,
	Subscription.SubscriptionId,
	Subscription.OrganizationId,
	SKU.ProductId,
	ProductRole.ProductRoleId,
	ProductRole.Name as ProductRoleName,
	ProductRole.PermissionAdmin
	FROM
	(
		(SELECT * FROM Auth.[User] WHERE UserId=@userId) as [User]
		join Billing.SubscriptionUser	ON SubscriptionUser.UserId=[User].UserId
		join Billing.Subscription		ON Subscription.SubscriptionId=SubscriptionUser.SubscriptionId
		join Billing.SKU				ON SKU.SKUId=Subscription.SKUId
		join Auth.ProductRole			ON ProductRole.ProductRoleId=SubscriptionUser.ProductRoleId
	)
	WHERE [SubscriptionUser].IsActive = 1
	  AND [Subscription].IsActive = 1
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[AddBillingHistory]
	@Description NVARCHAR(MAX), 
	@OrganizationId int, 
	@UserId NVARCHAR(50), 
	@ProductId int 
AS
	INSERT INTO Billing.BillingHistory ([Date], Description, OrganizationId, UserId, ProductId) VALUES (GETDATE(), @Description, @OrganizationId, @UserId, @ProductId) 


 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[AddOrgCustomer]
@OrgId int, 
@CustomerId NVARCHAR(50)
AS
	INSERT INTO Billing.OrganizationCustomer (OrgId, CustomerId) VALUES (@OrgId, @CustomerId)
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[AddBillingInformationForOrganization]
	@TokenId NVARCHAR(50),
	@OrgId int
AS
	INSERT INTO [Billing].OrganizationBillingTokens (TokenID, OrgId) VALUES (@TokenId, @OrgId)

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[AddOrgCustomer]
@OrgId int, 
@CustomerId NVARCHAR(50)
AS
	INSERT INTO Billing.OrganizationCustomer (OrgId, CustomerId) VALUES (@OrgId, @CustomerId)
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[AddSubscriptionPlan]
	@organizationid int,
	@customerid NVARCHAR(50),
	@subplanid NVARCHAR(50), 
	@accountid NVARCHAR(50),
	@numberofUsers int, 
	@price int,
	@productid int
AS
	
INSERT INTO Billing.CustomerSubscriptionPlan (OrganizationId, CustomerId, SubscriptionID, AccountID, NumberofUsers, Price, ProductId, IsActive) VALUES (@organizationid, @customerid, @subplanid, @accountid, @numberofUsers,@price, @productid, 1); 



 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
/*This query will change the SKU for an organization's subscription and will prevent multiple SKUs of the same product*/
CREATE procedure [Billing].[ChangeSubscription]
@OrganizationId int,
@SKUId int,
@productId int,/*Leave this null unless you are trying to delete something (unsubscribe)*/
@NumberOfUsers int,
@retId int OUTPUT
as
if(@SKUId =0)
	begin
		Delete from [Billing].[Subscription] where OrganizationId=@OrganizationId and SKUId in 
			(select SKUId from Billing.SKU where  ProductId=@productId);
		SET @retId = 0;
	end
else
	begin
		Update [Billing].[Subscription] set [SKUId]=@SKUId, [NumberOfUsers] = @NumberOfUsers WHERE OrganizationId=@OrganizationId and Subscription.IsActive = 1 and SKUId in 
		  (select SKUId from Billing.SKU where SKUId!=@SKUId and ProductId=(Select ProductId from Billing.SKU where SKUId=@SKUId) and OrganizationId=@OrganizationId);
		if(@@ROWCOUNT=0)
			begin
			insert into [Billing].[Subscription] (OrganizationId, SKUId, NumberOfUsers, CreatedDate)values (@OrganizationId, @SKUId, @NumberOfUsers, GETDATE());
			SET @retId = @@IDENTITY;
			end
		else
			SET @retId= 0;
	end
	
  
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[CheckSubscription]
	@OrganizationId int,
	@ProductId int
AS
	SELECT  [SubscriptionId],[SKU].SKUId, NumberOfUsers
  FROM [Billing].[Subscription] left join [Billing].[SKU] on [SKU].SKUId=Subscription.SKUId 
  where  OrganizationId=@OrganizationId and ProductId=@ProductId and IsActive = 1

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[CheckUserForAccessToProduct]
	@UserId varchar(40),
	@ProductId int
AS
	SELECT [src].[SubscriptionId], [Subscription].[SKUId], SKU.[ProductId], src.[ProductRoleId]
	FROM
	(
		(
			SELECT SubscriptionId, ProductRoleId, IsActive
			FROM [Billing].[SubscriptionUser]
			WHERE UserId=@UserId
		) AS src
		join [Billing].[Subscription]
			ON src.SubscriptionId=Subscription.SubscriptionId
		join [Billing].[SKU]
			ON Subscription.SKUId=SKU.SKUId
		join [Auth].[Organization]
			ON Subscription.OrganizationId=Organization.OrganizationId
		join [Auth].[ProductRole]
			ON src.ProductRoleId = ProductRole.ProductRoleId
	)
	WHERE SKU.ProductId=@ProductId
		AND Subscription.IsActive=1
		AND Organization.IsActive=1
		AND src.IsActive=1
		And ProductRole.Name != 'None'
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [Billing].[CreateOrgSKU]
	@OrganizationId int,
	@SKUId INT

AS
	if((select count(SubscriptionId)FROM Subscription WHERE IsActive=0 and OrganizationId=@OrganizationId)>0)
	
		BEGIN
			INSERT INTO [Billing].[Subscription] (OrganizationId, SKUId, CreatedDate, IsActive)
			VALUES (@OrganizationId,@SKUId,GETDATE(),1);
			
			return  1;
			
		END
		else
		begin
		return 0;
		end
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[CreateSubscriptionUser]	
	@SubscriptionId INT,
	@UserId NVARCHAR(40),
	@RoleId INT
AS
BEGIN
	UPDATE [Billing].[SubscriptionUser] 
	SET [IsActive] = 1, [ProductRoleId] = @RoleId
	WHERE [SubscriptionId] = @SubscriptionId AND [UserId] = @UserId

	IF @@ROWCOUNT=0
		INSERT INTO [Billing].[SubscriptionUser] (SubscriptionId, UserId, ProductRoleId)
		VALUES (@SubscriptionId, @UserId, @RoleId)
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[DeleteCustomerSubscription]
	@SubscriptionId NVARCHAR(50)
AS
	Update Billing.CustomerSubscriptionPlan SET IsActive = 0 WHERE SubscriptionID = @SubscriptionId; 


 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE procedure [Billing].[editProductRole]
 @productRoleId int,
 @SubscriptionId int,
 @UserId nvarchar(40)
 as
if (Select Name from Auth.ProductRole Where @productRoleId = ProductRoleId) != 'None'  
begin
	UPDATE [Billing].[SubscriptionUser] SET [ProductRoleId] =@productRoleId, IsActive = 1, [DateAdded]=GETDATE() where [SubscriptionId]=@SubscriptionId and [UserId]=@UserId ;
	if @@ROWCOUNT=0
	begin
		if (select count(UserId) from [Billing].SubscriptionUser where SubscriptionId=@SubscriptionId)<
		(SELECT UserLimit FROM [Billing].[SKU] where SKUId=(SELECT SKUId FROM Billing.Subscription where SubscriptionId=@SubscriptionId))
		insert into [Billing].[SubscriptionUser] (SubscriptionId,UserId,ProductRoleId,IsActive, DateAdded) values(@SubscriptionId,@UserId,@productRoleId,1, GETDATE());
	end
end 
else
	UPDATE [Billing].[SubscriptionUser] set IsActive = 0, [DateAdded] = NULL where [SubscriptionId]=@SubscriptionId and [UserId]=@UserId;
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetDateAddedToSubscriptionByUserId]
	@UserId nvarchar(40),
	@SubscriptionId int
as
	SELECT DateAdded from Billing.SubscriptionUser 
	WHERE SubscriptionUser.UserId =@UserId 
	AND SubscriptionUser.SubscriptionId = @SubscriptionId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetFreeSKU]
	@ProductID int
AS
	SELECT SKUId, ProductId, Name, Price, UserLimit, BillingFrequency FROM [Billing].[SKU]
	WHERE ProductId = @ProductID and BillingFrequency = 'Free'

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE Billing.getMaxUsersforSubscriptions
@SubscriptionId int
as
(SELECT UserLimit FROM [Billing].[SKU] where SKUId=(SELECT SKUId FROM Billing.Subscription where SubscriptionId=@SubscriptionId))
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
Create PROCEDURE [Billing].[GetOrganizationsByUserProductAccess]
	@UserId varchar(40),
	@ProductId int
AS
	SELECT [Organization].[Name], [Organization].[OrganizationId]
	FROM
	(
		(
			SELECT SubscriptionId, ProductRoleId, IsActive
			FROM [Billing].[SubscriptionUser]
			WHERE UserId=@UserId
		) AS src
		join [Billing].[Subscription]
			ON src.SubscriptionId=Subscription.SubscriptionId
		join [Billing].[SKU]
			ON Subscription.SKUId=SKU.SKUId
		join [Auth].[Organization]
			ON Subscription.OrganizationId=Organization.OrganizationId
		join [Auth].[ProductRole]
			ON src.ProductRoleId = ProductRole.ProductRoleId
	)
	WHERE SKU.ProductId=@ProductId
		AND Subscription.IsActive=1
		AND Organization.IsActive=1
		AND src.IsActive=1
		And ProductRole.Name != 'None'
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetOrganizationsWhereUserIsAdmin]
	@UserId varchar(40)
AS
SELECT Name, [Organization].OrganizationId FROM [Auth].OrganizationUser 
LEFT JOIN [Auth].[Organization] ON [Organization].[OrganizationId]=[OrganizationUser].OrganizationId 
WHERE UserId=@UserId AND OrganizationUser.IsActive = 1 AND Organization.IsActive = 1 AND OrganizationUser.OrgRoleId = 2
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[getOrgByUser]
	@UserId varchar(40)
AS
SELECT Name, [Organization].OrganizationId FROM [Auth].OrganizationUser 
LEFT JOIN [Auth].[Organization] ON [Organization].[OrganizationId]=[OrganizationUser].OrganizationId 
WHERE UserId=@UserId AND OrganizationUser.IsActive = 1 AND Organization.IsActive = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetOrgCustomer]
@OrgId int
AS
	SELECT CustomerId FROM Billing.OrganizationCustomer WHERE OrgId = @OrgId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetOrgSKUId]
	@ProductName nvarchar(128)
AS
	SELECT [SKU].[SKUId] from [Billing].[SKU] where [Billing].[SKU].[Name] = @ProductName;

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetOrgSKUs]
	@OrganizationId INT
AS
BEGIN
	SELECT [A2].[SubscriptionId], [A1].[Name], [A2].[UserCount], A1.SKUId
	FROM
	(
		SELECT [OrgSub].[OrganizationId],[OrgSub].[SKUId] , [Name]
		FROM [Billing].[Subscription] AS [OrgSub]
		INNER JOIN 
		(
			SELECT [SKU].[SKUId], [Product].[Name]
			FROM [Billing].[Product] AS [Product]
			INNER JOIN [Billing].[SKU] AS [SKU]
			ON [Product].[ProductId] = [SKU].[ProductId]
		) AS [ProductSKU]
		ON [OrgSub].[SKUId] = [ProductSKU].[SKUId] AND [OrgSub].[IsActive] = 1
		WHERE [OrgSub].[OrganizationId] = @OrganizationId
	) AS [A1]
	INNER JOIN
	(
		SELECT [SubUser].[SubscriptionId], COUNT(*) AS [UserCount]
		FROM [Billing].[SubscriptionUser] AS [SubUser]
		INNER JOIN [Billing].[Subscription] AS [OrgSubs]
		ON [SubUser].[SubscriptionId] = [OrgSubs].[SubscriptionId]
		WHERE [OrgSubs].[OrganizationId] = @OrganizationId AND [OrgSubs].[IsActive] = 1
		GROUP BY [SubUser].[SubscriptionId]
	) AS [A2]
	ON [A1].[SKUId] = [A2].SubscriptionId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [Billing].[GetProductById]
	@productId int 
AS
	SELECT [Name]
      ,[Description]
  FROM [Billing].[Product] WHERE [ProductId]=@productId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetProductIds]
AS
	SELECT [ProductId] FROM [Billing].[Product];

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create procedure Billing.getProductRolesFromSubscription
@SubscriptionId int
as
SELECT ProductRole.Name, ProductRole.ProductRoleId from
  [Billing].[Subscription]
   left join [Billing].[SKU] on SKU.SKUId=Subscription.SKUId 
  right join [Auth].[ProductRole]  on [ProductRole].ProductId=SKU.ProductId
 where SubscriptionId=@SubscriptionId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetProducts]
AS
	SELECT [Billing].[Product].[ProductId], [Billing].[Product].[Name] from [Billing].[Product]

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
/*
	Returns a mapping of SubscriptionId to name of
	the product that subscription is for.
	For example, an organization's subscription
	ID 1 may be assigned to SKUId 3, which is for
	the TimeTracker product. This maps that 
	subscription id 1 to TimeTracker.
*/

CREATE PROCEDURE [Billing].[GetProductSKU]
	@OrganizationId INT
AS
BEGIN
	SELECT [OrgSKU].[OrganizationId], [OrgSKU].[SKUId],  [Name]
	FROM [Billing].[Subscription] AS [OrgSKU]
	INNER JOIN 
	(
		SELECT [SKU].[SKUId], [Product].[Name]
		FROM [Billing].[Product] AS [Product]
		INNER JOIN [Billing].[SKU] AS [SKU]
		ON [Product].[ProductId] = [SKU].[ProductId]
	) AS [ProductSKUs]
	ON [OrgSKU].[SKUId] = [ProductSKUs].[SKUId] AND [OrgSKU].[IsActive] = 1
	WHERE [OrgSKU].[OrganizationId] = @OrganizationId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSKU]
	@SKUId int
AS
	SELECT [SKUId]
      ,[ProductId]
      ,[Name]
      ,[Price]
      ,[UserLimit]
      ,[BillingFrequency] FROM [Billing].[SKU] WHERE [SKUId] = @SKUId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSKUforProduct]
	@ProductId int
AS
	SELECT [SKUId]
      ,[Name]
      ,[Price]
      ,[UserLimit]
      ,[BillingFrequency]
  FROM [Billing].[SKU] where [Billing].[SKU].[ProductId]=@ProductId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSubscriptionByOrgAndProduct]
@OrganizationId int,
@ProductId int
as
SELECT Name, Price,UserLimit,BillingFrequency, Subscription.SubscriptionId
  FROM [Billing].[Subscription]
  LEFT JOIN [Billing].[SKU] on [Subscription].SKUId=[SKU].SKUId

  where [Subscription].[OrganizationId]=@OrganizationId
    AND [SKU].[ProductId]=@ProductId
	AND IsActive=1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[getSubscriptionByUser]
@UserId varchar(40)
AS
SELECT [organization].Name AS organizationName,[SKU].Name, CreatedDate, [Subscription].SubscriptionId,Organization.OrganizationId FROM 
	(SELECT [SubscriptionId] FROM [Billing].[SubscriptionUser] WHERE UserId=@UserId AND IsActive = 1) AS src 
	JOIN [Billing].[Subscription] ON src.[SubscriptionId]=[Subscription].[SubscriptionId]
	JOIN [Billing].[SKU] ON [Subscription].SKUId=SKU.SKUId
	JOIN [Auth].[Organization] ON [Organization].OrganizationId=[Subscription].OrganizationId
	WHERE [Organization].[IsActive] = 1 AND [Subscription].[IsActive] = 1 
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSubscriptionDetailsById]
	@SubscriptionId int
AS
Select [OrganizationId]
      ,[SKUId]
	  ,[NumberOfUsers]
      ,[CreatedDate]
      ,[IsActive] from Billing.Subscription where SubscriptionId = @SubscriptionId and IsActive = 1

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSubscriptionPlan]
	@customerid NVARCHAR(50), 
	@organizationid int
AS
	
SELECT Billing.CustomerSubscriptionPlan.SubscriptionID FROM Billing.CustomerSubscriptionPlan WHERE CustomerId = @customerid AND @organizationid = OrganizationId AND IsActive = 1; 


 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSubscriptionPlanNumberOfUsers]
	@subscriptionid NVARCHAR(50)
AS
	
SELECT Billing.CustomerSubscriptionPlan.NumberofUsers FROM Billing.CustomerSubscriptionPlan WHERE  @subscriptionid = SubscriptionID; 
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSubscriptionPlanPrice]
	@subscriptionid NVARCHAR(50)
	
AS
	
SELECT Billing.CustomerSubscriptionPlan.Price FROM Billing.CustomerSubscriptionPlan WHERE @subscriptionid = SubscriptionID AND IsActive = 1;  
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSubscriptionsByOrg]
@OrganizationId int
as
SELECT Name, Price,UserLimit,BillingFrequency, Subscription.SubscriptionId, Subscription.SKUId
  FROM [Billing].[Subscription]left join [Billing].[SKU] on [Subscription].SKUId=[SKU].SKUId where [Subscription].[OrganizationId]=@OrganizationId and IsActive=1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSubscriptionsDisplayByOrg]
@OrganizationId int
as
SELECT	Product.ProductId,
		Product.Name as ProductName,
		Subscription.SubscriptionId,
		Organization.OrganizationId,
		Subscription.SKUId,
		Subscription.NumberOfUsers,
		Organization.Name as OrganizationName,
		SKU.Name as SKUName,
		Tier
  FROM [Billing].[Subscription]
  left join [Billing].[SKU] on [Subscription].SKUId=[SKU].SKUId
  left join [Auth].[Organization] on Organization.OrganizationId=Subscription.OrganizationId
  left join Billing.Product on SKU.ProductId=Product.ProductId
  where [Subscription].[OrganizationId]=@OrganizationId
	and Subscription.IsActive=1 and Organization.IsActive=1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetTokenByOrg]
	@OrgId int
AS
	SELECT TokenID FROM Billing.OrganizationBillingTokens WHERE OrgId = @OrgId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 

create procedure [Billing].[getUsersByOrganization]
@OrganizationId int,
@SubscriptionId int
as

SELECT [FirstName] ,LastName, ProductRoleId, [User].UserId
  FROM [Auth].[OrganizationUser] 
  left join [Auth].[User] on [OrganizationUser].[UserId]=[User].[UserId] 
left join(select  UserId, ProductRoleId from[Billing].[SubscriptionUser] where SubscriptionId=@SubscriptionId and IsActive=1 ) as  onroles on [User].UserId=onroles.UserId 
  where OrganizationId=@OrganizationId and OrganizationUser.IsActive = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[RemoveSubscriptionFromOrganization]
	@orgId int,
	@SKUId int
AS
Begin
	Update [Billing].[Subscription]
	Set [IsActive] = 0 
	WHERE [SKUId] = @SKUId AND [OrganizationId] = @orgId
End
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
--DECLARE @userId varchar(40) = '105b34f5-8b59-4f01-b42a-ae9de49ed71f';
CREATE procedure [Billing].[SubscriptionDetailsByUser]
	@userId varchar(40)
AS
BEGIN
	SELECT
	Organization.OrganizationId as OrganizationId,
	ProductId as ProductId,
	Organization.Name	  as OrganizationName,
	SKU.Name			  as SKUName,
	Subscription.SubscriptionId as SubscriptionId,
	SKU.SKUId as SKUID,
	SKU.Name as SKUName
	FROM
	(
		(SELECT * FROM Auth.OrganizationUser WHERE UserId=@userId) as user_org
		join Auth.Organization ON Organization.OrganizationId=user_org.OrganizationId
		join Billing.Subscription ON Subscription.OrganizationId=Organization.OrganizationId
		join Billing.SKU ON SKU.SKUId=Subscription.SKUId
	)
	WHERE user_org.IsActive = 1 AND Organization.IsActive = 1 AND Subscription.IsActive = 1
	ORDER BY OrgRoleId DESC, Organization.Name ASC, BillingFrequency DESC
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
Create PROCEDURE [Billing].[Unsubscribe]
	@SubscriptionId int
AS
	UPDATE Billing.Subscription set IsActive = 0 Where SubscriptionId = @SubscriptionId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[UpdateBillingInfo]
	@TokenId NVARCHAR(50),
	@OrgId int
AS
	UPDATE[Billing].OrganizationBillingTokens set TokenID = @TokenId WHERE OrgId = @OrgId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[UpdateSubscriptionPlan]
	@customerid NVARCHAR(50),
	@subplanid NVARCHAR(50), 
	@accountid NVARCHAR(50),
	@numberofusers int, 
	@price int
AS
	
UPDATE Billing.CustomerSubscriptionPlan SET SubscriptionID = @subplanid, NumberofUsers = @numberofusers, Price = @price WHERE CustomerId = @customerid AND AccountID = @accountid;

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create procedure [Billing].[getOrgByUser]
@UserId varchar(40)
as
select Name, [Organization].OrganizationId from [Auth].OrganizationUser 
left join [Auth].[Organization] on [Organization].[OrganizationId]=[OrganizationUser].OrganizationId where UserId=@UserId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetOrgCustomer]
@OrgId int
AS
	SELECT CustomerId FROM Billing.OrganizationCustomer WHERE OrgId = @OrgId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSubscriptionPlanNumberOfUsers]
	@customerid NVARCHAR(50), 
	@accountid NVARCHAR(50)
AS
	
SELECT Billing.CustomerSubscriptionPlan.NumberofUsers FROM Billing.CustomerSubscriptionPlan WHERE CustomerId = @customerid AND @accountid = AccountID; 
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[GetSubscriptionPlanPrice]
	@customerid NVARCHAR(50), 
	@accountid NVARCHAR(50)
AS
	
SELECT Billing.CustomerSubscriptionPlan.Price FROM Billing.CustomerSubscriptionPlan WHERE CustomerId = @customerid AND @accountid = AccountID; 
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[UpdateBillingInfo]
	@TokenId NVARCHAR(50),
	@OrgId int
AS
	UPDATE[Billing].OrganizationBillingTokens set TokenID = @TokenId WHERE OrgId = @OrgId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[UpdateSubscriptionPlan]
	@customerid NVARCHAR(50),
	@subplanid NVARCHAR(50), 
	@accountid NVARCHAR(50)
AS
	
UPDATE Billing.CustomerSubscriptionPlan SET SubscriptionID = @subplanid WHERE CustomerId = @customerid AND AccountID = @accountid;

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
/*This query will change the SKU for an organization's subscription and will prevent multiple SKUs of the same product*/
CREATE procedure [Billing].[UpdateNumberofUsersSubscription]
@OrganizationId int,
@SKUId int,
@NumberOfUsers int
as

		Update [Billing].[Subscription] set [NumberOfUsers] = @NumberOfUsers WHERE OrganizationId=@OrganizationId and Subscription.IsActive = 1 and SKUId = @SKUId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Billing].[UpdateOrgCustomer]
@OrgId int, 
@CustomerId NVARCHAR(50)
AS
	UPDATE Billing.OrganizationCustomer SET CustomerId = @CustomerId WHERE OrgId = @OrgId;
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
Create PROCEDURE [Customer].[CreateInfo]
	@Name NVARCHAR(50),
    @Address NVARCHAR(100),
    @City NVARCHAR(100), 
    @State NVARCHAR(100), 
    @Country NVARCHAR(100), 
    @ZipCode NVARCHAR(50),
	@ContactEmail NVARCHAR(50), 
    @ContactPhoneNumber NVARCHAR(50),
	@FaxNumber NVARCHAR(50),
	@Website NVARCHAR(50),
	@EIN NVARCHAR(50),
	@OrganizationID INT
AS
BEGIN
	INSERT INTO [Shared].[Customer] ( Name, [Address], City, [State], Country, ZipCode, ContactEmail, ContactPhoneNumber, FaxNumber, Website, EIN, OrganizationId, DateCreated)
	VALUES (@Name, @Address, @City, @State, @Country, @ZipCode, @ContactEmail, @ContactPhoneNumber, @FaxNumber, @Website, @EIN, @OrganizationID, GetDate());
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Customer].[DeleteCustomer]
	@CustomerID INT
AS
BEGIN
	UPDATE [Shared].[Customer] SET IsActive = 0 WHERE [Customer].[CustomerId] = @CustomerID; 
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Customer].[GetCustomersByOrgID]
@OrgId INT
AS
	BEGIN
	SELECT [Customer].[CustomerId],
		   [Customer].[Name],
		   [Customer].[Address],
		   [Customer].[City],
		   [Customer].[State],
		   [Customer].[Country],
		   [Customer].[ZipCode],
		   [Customer].[ContactEmail],
		   [Customer].[ContactPhoneNumber],
		   [Customer].[FaxNumber],
		   [Customer].[Website],
		   [Customer].[EIN],
		   [Customer].[DateCreated]
	FROM [Shared].[Customer] AS [Customer]
	WHERE [Customer].OrganizationId = @OrgId
	AND [Customer].IsActive = 1
END 

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Customer].[ReadInfo]
	@CustomerId INT
AS
BEGIN
	SELECT [Customer].[CustomerId],
		   [Customer].[Name],
		   [Customer].[Address],
		   [Customer].[City],
		   [Customer].[State],
		   [Customer].[Country],
		   [Customer].[ZipCode],
		   [Customer].[ContactEmail],
		   [Customer].[ContactPhoneNumber],
		   [Customer].[FaxNumber],
		   [Customer].[Website],
		   [Customer].[EIN],
		   [Customer].[DateCreated],
		   [Customer].[OrganizationId]
	FROM [Shared].[Customer] AS [Customer]
	WHERE [CustomerId] = @CustomerId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Customer].[UpdateInfo]
	@CustomerId INT,
	@Name NVARCHAR(50),
	@ContactEmail NVARCHAR(50),
    @Address NVARCHAR(100), 
    @City NVARCHAR(100), 
    @State NVARCHAR(100), 
    @Country NVARCHAR(100), 
    @ZipCode NVARCHAR(50),
    @ContactPhoneNumber NVARCHAR(50),
	@FaxNumber NVARCHAR(50),
	@Website NVARCHAR(50),
	@EIN NVARCHAR(50)
AS
BEGIN
	UPDATE [Shared].[Customer]
	SET [Name] = @Name,
		[ContactEmail]=@ContactEmail,
		[Address] = @Address,
		[City] = @City, 
		[State] = @State, 
		[Country] = @Country, 
		[ZipCode] = @ZipCode, 
		[ContactPhoneNumber] = @ContactPhoneNumber, 
		[FaxNumber] = @FaxNumber,
		[Website] = @Website,
		[EIN] = @EIN
	WHERE [CustomerId] = @CustomerId 
	AND [IsActive] = 1
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
--DECLARE @userId nvarchar(40) = '5d67b87f-bbc5-4d59-8f62-e662f19c72c9';

CREATE PROCEDURE Shared.GetCustomerOrgInfoByUserId
	@userId nvarchar(40)
AS
	SELECT CustomerId, Customer.Name as CustomerName, Organization.OrganizationId, Organization.Name as OrganizationName FROM (
		(SELECT [OrganizationId] FROM Auth.OrganizationUser WHERE UserId = @userId) as OrganizationUser
			JOIN Auth.Organization ON Organization.OrganizationId=OrganizationUser.OrganizationId
			JOIN Shared.Customer ON Customer.OrganizationId=OrganizationUser.OrganizationId
	) WHERE Organization.IsActive = 1
	AND [Customer].[IsActive] = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
--DECLARE @userId nvarchar(40) = '5d67b87f-bbc5-4d59-8f62-e662f19c72c9';

CREATE PROCEDURE Shared.GetCustomerOrgInfoByUserIdWhereAdmin
	@userId nvarchar(40)
AS
	SELECT CustomerId,
		   Customer.Name as CustomerName,
		   Organization.OrganizationId,
		   Organization.Name as OrganizationName,
		   Subscription.SubscriptionId FROM (
		(SELECT * FROM Auth.OrganizationUser WHERE UserId = @userId) as OrganizationUser
			JOIN Auth.Organization ON Organization.OrganizationId=OrganizationUser.OrganizationId
			JOIN Shared.Customer ON Customer.OrganizationId=OrganizationUser.OrganizationId
			JOIN Billing.Subscription ON Organization.OrganizationId=Subscription.OrganizationId
			JOIN Billing.SubscriptionUser ON Subscription.SubscriptionId=SubscriptionUser.SubscriptionId AND SubscriptionUser.UserId=@userId
			JOIN Auth.ProductRole ON ProductRole.ProductRoleId=SubscriptionUser.ProductRoleId
	) WHERE Organization.IsActive = 1 AND SubscriptionUser.IsActive = 1 AND ProductRole.PermissionAdmin = 1 and Customer.IsActive = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Lookup].[GetCountries]
AS
	SELECT Name FROM [Lookup].[Country];

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Lookup].[GetStatesByCountry]
	@CountryName NVARCHAR(50)
AS
BEGIN
	SELECT [Lookup].[State].[Name]
	FROM [Lookup].[State]
	INNER JOIN [Lookup].[Country]
	ON [Lookup].[State].[Code] = [Lookup].[Country].[Code]
	WHERE [Lookup].[Country].[Name] = @CountryName
	ORDER BY [Lookup].[State].[Name]
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[Create]
	@UserId NVARCHAR(40),
	@RoleId INT,
	@Name NVARCHAR(100),
	@SiteUrl NVARCHAR(100),
    @Address NVARCHAR(100),
    @City NVARCHAR(100),
    @State NVARCHAR(100),
    @Country NVARCHAR(100),
    @ZipCode NVARCHAR(50),
	@PhoneNumber NVARCHAR(50),
	@Subdomain NVARCHAR(50),
    @retId INT OUTPUT
AS
BEGIN
	SET XACT_ABORT ON
	BEGIN TRANSACTION
		INSERT INTO [Auth].[Organization] (Name, SiteUrl, [Address], City, [State], Country, ZipCode, PhoneNumber, Subdomain, [DateCreated])
		VALUES (@Name, @SiteUrl, @Address, @City, @State, @Country, @ZipCode, @PhoneNumber, @Subdomain, GETDATE());
		SET @retId = SCOPE_IDENTITY();
		EXEC [OrgUser].[Create] @UserId, @retId, @RoleId
	COMMIT TRANSACTION
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[CreateUserInvitation]
	@Email nvarchar(40),
	@FirstName nvarchar(40),
	@LastName nvarchar(40),
	@DateOfBirth NVARCHAR(40),
	@OrganizationId int,
	@AccessCode NVARCHAR(50)
as
	INSERT INTO Auth.Invitation ([Email], [FirstName], [LastName], [DateOfBirth], [OrganizationId],[AccessCode])
	VALUES (@Email, @FirstName, @LastName, @DateOfBirth, @OrganizationId, @AccessCode)
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
Create Procedure [Org].[Delete]
	@OrgId int
As 
	UPDATE Auth.Organization SET IsActive = 0 Where OrganizationId = @OrgId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[FindByKey]
	@AccessCode NVARCHAR(10)
AS
BEGIN
	SELECT [OrganizationId], [Name], [SiteUrl], [Address], [City],[State],[Country],[ZipCode],[PhoneNumber],[AccessCode]
	FROM [Auth].[Organization]
	WHERE ISNULL([AccessCode], '') = @AccessCode 
	AND Organization.IsActive = 1
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[GetIdBySubdomain]
	@Subdomain nvarchar(50)
AS
	SELECT TOP 1 [OrganizationId] from [Auth].[Organization] WHERE @Subdomain = [Subdomain]
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE Procedure [Org].[GetNumberOfSubscriptions]
	@OrgId int
AS
SELECT COUNT(DISTINCT SubscriptionId) 
	FROM [Billing].[Subscription] LEFT JOIN [Auth].[OrganizationUser]
	on [Subscription].[OrganizationId] = [Auth].[OrganizationUser].[OrganizationId] 
where [Auth].[OrganizationUser].[IsActive] = 1 
	and [OrganizationUser].[OrganizationId] = @OrgId
	and Subscription.IsActive = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[GetOrganizationsByUserId]
	@UserId nvarchar(40)
AS
SELECT [Auth].[Organization].[OrganizationId]
      ,[Name]
      ,[SiteUrl]
      ,[Address]
      ,[City]
      ,[State]
      ,[Country]
      ,[ZipCode]
      ,[PhoneNumber]
      ,[AccessCode]
      ,[DateCreated] FROM [Auth].[Organization] RIGHT JOIN Auth.OrganizationUser on Organization.OrganizationId = OrganizationUser.OrganizationId
Where @UserId = OrganizationUser.UserId 
AND OrganizationUser.IsActive = 1
AND Organization.IsActive = 1
Order By OrganizationUser.OrgRoleId DESC, Organization.DateCreated
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE Org.[GetOrganizationsWhereUserIsAdmin]
	@UserId varchar(40)
AS
SELECT Name, [Organization].OrganizationId FROM [Auth].OrganizationUser 
LEFT JOIN [Auth].[Organization] ON [Organization].[OrganizationId]=[OrganizationUser].OrganizationId 
WHERE UserId=@UserId AND OrganizationUser.IsActive = 1 AND Organization.IsActive = 1 AND OrganizationUser.OrgRoleId = 2
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[getOrgByUser]
	@UserId varchar(40)
AS
SELECT Name, [Organization].OrganizationId FROM [Auth].OrganizationUser 
LEFT JOIN [Auth].[Organization] ON [Organization].[OrganizationId]=[OrganizationUser].OrganizationId 
WHERE UserId=@UserId AND OrganizationUser.IsActive = 1 AND Organization.IsActive = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[GetSubdomainById]
	@OrgId int
AS
	SELECT TOP 1 [Subdomain] from [Auth].[Organization] WHERE @OrgId = OrganizationId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[GetUserCount]
	@OrganizationId INT
AS
BEGIN
	SELECT COUNT(*) FROM [Auth].[OrganizationUser] WHERE [OrganizationId] = @OrganizationId AND [IsActive] = 1
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[GetUserDetailsByOrganization]
	@UserId nvarchar(40),
	@OrgId int
AS
SELECT OrganizationId, OrgRoleId, IsActive, DateAdded FROM [Auth].[OrganizationUser] 
WHERE [OrganizationId]  = @OrgId AND [UserId] = @UserId AND [IsActive] = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[GetUserInvitationsByOrgId]
	@OrganizationId int
as
	SELECT [InvitationId], [Email], [FirstName], [LastName], [DateOfBirth], [OrganizationId], Auth.Invitation.AccessCode FROM [Auth].[Invitation]
	WHERE [OrganizationId] = @OrganizationId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[GetUserInvitationsByUserData]
	@Email nvarchar(40),
	@FirstName nvarchar(40),
	@LastName nvarchar(40),
	@DateOfBirth NVARCHAR(50)
as
	SELECT [InvitationId], [Email], [FirstName], [LastName], [DateOfBirth], [OrganizationId], [AccessCode] FROM [Auth].[Invitation]
	WHERE [Email] = @Email 
	AND [FirstName] = @FirstName
	AND [LastName] = @LastName
	AND [DateOfBirth] = @DateOfBirth
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[GetUserList]
	@OrganizationId INT
AS
BEGIN
	SELECT [OU].[OrganizationId],
	       [OU].[UserId],
		   [OU].[OrgRoleId],
		   [U].[FirstName],
		   [U].[LastName]
    FROM [Auth].[OrganizationUser] AS [OU]
    INNER JOIN [Auth].[User] AS [U]
    ON [OU].[UserId] = [U].[UserId]
    WHERE [OU].[OrganizationId] = @OrganizationId AND [IsActive] = 1
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[Read]
	@OrganizationId INT
AS
BEGIN
	SELECT *
	FROM [Auth].[Organization] AS [Org] 
	WHERE [OrganizationId] = @OrganizationId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[RemoveUserInvitation]
	@InvitationId int
as
	Delete FROM [Auth].[Invitation]
	WHERE [InvitationId] = @InvitationId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[Update]
	@Id INT,
	@Name NVARCHAR(100),
	@SiteUrl NVARCHAR(100),
    @Address NVARCHAR(100), 
    @City NVARCHAR(100), 
    @State NVARCHAR(100), 
    @Country NVARCHAR(100), 
    @ZipCode NVARCHAR(50),
	@PhoneNumber NVARCHAR (50)
AS
BEGIN
	UPDATE [Auth].[Organization]
	SET [Name] = @Name, [SiteUrl] = @SiteUrl, [Address] = @Address, [City] = @City, [State] = @State, [Country] = @Country, [ZipCode] = @ZipCode, [PhoneNumber] = @PhoneNumber
	WHERE [OrganizationId] = @Id	
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Org].[UpdateAccessCode]
	@OrganizationId INT,
	@AccessCode NVARCHAR(10)
AS
BEGIN
	UPDATE [Auth].[Organization] SET [AccessCode] = @AccessCode
	WHERE [OrganizationId] = @OrganizationId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [OrgUser].[Create]
    @UserId NVARCHAR(40),
    @OrganizationId INT,
    @RoleId INT
AS
BEGIN
	UPDATE [Auth].[OrganizationUser]
	SET [IsActive] = 1, [OrgRoleId] = @RoleId
	WHERE [UserId] = @UserId AND [OrganizationId] = @OrganizationId;

	IF @@ROWCOUNT=0
		INSERT INTO [Auth].[OrganizationUser] (UserId, OrganizationId, OrgRoleId, DateAdded)
		VALUES (@UserId, @OrganizationId, @RoleId, GETDATE())
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [OrgUser].[GetRole]
	@OrganizationId INT,
	@UserId NVARCHAR(40)
AS
BEGIN
	SELECT [OrgRole].[OrgRoleId] as Id, [OrgRole].[Name] FROM [Auth].[OrganizationUser] as [User] 
	inner join [Auth].[OrgRole] as [OrgRole] on [User].[OrgRoleId] = [OrgRole].[OrgRoleId] 
	WHERE [User].[OrganizationId] = @OrganizationId AND [User].[UserId] = @UserId AND [IsActive] = 1 AND 
		(SELECT IsActive From Auth.Organization where [Organization].OrganizationId = @OrganizationId) = 1
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [OrgUser].[Remove]
	@OrganizationId INT,
	@UserId NVARCHAR(40)
AS
BEGIN
	UPDATE [Auth].[OrganizationUser] SET [IsActive] = 0 WHERE [OrganizationId] = @OrganizationId AND [UserId] = @UserId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [OrgUser].[Update]
	@OrganizationId INT,
	@UserId NVARCHAR(40),
	@RoleId INT
AS
BEGIN
	UPDATE [Auth].[OrganizationUser] SET [OrgRoleId] = @RoleId
	WHERE [OrganizationId] = @OrganizationId AND [UserId] = @UserId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[AddAccessCode]
	@Code int = 0,
	@OrgId int
AS
	Insert INTO Auth.AccessCodes (Code, OrgId) VALUES (@Code, @OrgId)
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[GetOrgFromAccessCode]
	@AccessCode NVARCHAR(50)
AS
	SELECT Auth.AccessCodes.OrgId FROM Auth.AccessCodes WHERE @AccessCode = Code

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[GetProjectsByCustomer]
	@CustomerId int
AS
	Select Name,
		   ProjectId
	FROM [Shared].[Project]
	WHERE IsActive = 1 and CustomerId = @CustomerId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[RemoveAccessCode]
	@Code NVARCHAR(50)
AS
	DELETE FROM Auth.AccessCodes WHERE Code = @Code

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[CreateProject]
	@organizationId int,
	@customerId int,
	@name nvarchar(max),
    @retId INT OUTPUT
AS
BEGIN
	BEGIN TRANSACTION
	INSERT INTO [Shared].[Project]
			( OrganizationId,  CustomerId,  Name)
	VALUES	(@organizationId, @customerId, @name);
	SET @retId = SCOPE_IDENTITY()
	COMMIT TRANSACTION
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[CreateProjectFromCustomerIdOnly]
	@customerId int,
	@name nvarchar(max),
	@retId INT OUTPUT
AS
BEGIN
	BEGIN TRANSACTION
	INSERT INTO [Shared].[Project]
			( OrganizationId,  CustomerId,  Name)
	VALUES	( (SELECT OrganizationId FROM Shared.Customer WHERE CustomerId=@customerId),
				@customerId, @name)
	SET @retId = SCOPE_IDENTITY()
	COMMIT TRANSACTION
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[CreateProjectUser]
	@ProjectId int,
	@UserId nvarchar(40),
	@ret int OUTPUT
AS
BEGIN 
	BEGIN TRANSACTION
	INSERT INTO [Shared].[ProjectUser] (ProjectId, UserId, IsActive, DateAdded)
	VALUES(@ProjectId, @UserId, 1, GETDATE());
	SET @ret = 1
	COMMIT TRANSACTION
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[DeleteProject]
	@projectId int
AS
	UPDATE [Shared].[Project]
	SET IsActive = 0
	WHERE ProjectId = @projectId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[DeleteProjectUser]
	@ProjectId int,
	@UserId nvarchar(40),
	@ret int OUTPUT
AS
BEGIN 
	BEGIN TRANSACTION
	UPDATE [Shared].[ProjectUser] SET IsActive = 0 
	WHERE ProjectId = @ProjectId 
	AND UserId = @UserId;
	SET @ret = 1
	COMMIT TRANSACTION
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[GetProjectById]
	@projectId int
AS
	SELECT	Project.ProjectId,
			Project.CustomerId,
			Project.OrganizationId,
			Project.Created,
			Project.Name as ProjectName,
			Organization.Name as OrganizationName,
			Customer.Name as CustomerName
			FROM (
		(SELECT * FROM Shared.Project WHERE ProjectId=@projectId) as Project
			JOIN Auth.Organization ON Organization.OrganizationId=Project.OrganizationId
			JOIN Shared.Customer ON Customer.CustomerId=Project.CustomerId
	) WHERE Organization.IsActive=1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[GetProjectsByCustomer]
	@CustomerId int
AS
	Select Name,
		   ProjectId
	FROM [Shared].[Project]
	WHERE IsActive = 1 and CustomerId = @CustomerId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[GetProjectsByUser]
	@userId nvarchar(40)
AS
	SELECT	Project.ProjectId,
			Project.CustomerId,
			Project.OrganizationId,
			Project.Created,
			Project.Name as ProjectName,
			Organization.Name as OrganizationName,
			Customer.Name as CustomerName,
			OrgRoleId
			FROM (
		(SELECT OrganizationId, UserId, OrgRoleId FROM Auth.OrganizationUser WHERE UserId=@userId) as OrganizationUser
		JOIN Auth.Organization ON OrganizationUser.OrganizationId=Organization.OrganizationId
		JOIN Shared.Project ON Project.OrganizationId=Organization.OrganizationId
		JOIN Shared.Customer ON Project.CustomerId=Customer.CustomerId
	) WHERE Organization.IsActive=1
		AND Customer.IsActive=1
		AND Project.IsActive=1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[GetProjectsByUserAndOrganization]
	@userId nvarchar(40),
	@orgId int,
	@activity int = 1
AS
	SELECT	Project.ProjectId,
			Project.CustomerId,
			Project.OrganizationId,
			Project.Created,
			Project.Name as ProjectName,
			Project.IsActive,
			Organization.Name as OrganizationName,
			Customer.Name as CustomerName,
			Customer.IsActive as IsCustomerActive,
			OrgRoleId
			FROM (
		(SELECT OrganizationId, UserId, OrgRoleId FROM Auth.OrganizationUser WHERE UserId=@userId and OrganizationId = @orgId) as OrganizationUser
		JOIN Auth.Organization ON OrganizationUser.OrganizationId=Organization.OrganizationId
		JOIN Shared.Project ON Project.OrganizationId=Organization.OrganizationId
		JOIN Shared.Customer ON Project.CustomerId=Customer.CustomerId
	) WHERE Organization.IsActive=1
		AND Customer.IsActive >= @activity
		AND Project.IsActive >= @activity

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[GetProjectsByUserId]
	@UserId nvarchar(40)
AS
BEGIN 
	BEGIN TRANSACTION
	SELECT [ProjectUser].[ProjectId],
		   [Project].[Name] As ProjectName,
		   [Project].[OrganizationId],
		   [Customer].[CustomerId],
		   [Customer].[Name] As CustomerName
	FROM [Shared].[ProjectUser] 
	LEFT JOIN [Shared].[Project] ON [ProjectUser].ProjectId = Project.ProjectId
	LEFT JOIN [Shared].[Customer] ON [Customer].CustomerId = Project.CustomerId
	LEFT JOIN [Auth].[Organization] ON Organization.OrganizationId = Customer.OrganizationId
	WHERE Organization.IsActive = 1 
	AND Customer.IsActive = 1 
	AND Project.IsActive = 1
	AND ProjectUser.UserId = @UserId
	COMMIT TRANSACTION
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[GetProjectsByUserIsOwner]
	@userId nvarchar(40)
AS
	SELECT	Project.ProjectId,
			Project.CustomerId,
			Project.OrganizationId,
			Project.Created,
			Project.Name as ProjectName,
			Organization.Name as OrganizationName,
			Customer.Name as CustomerName
			FROM (
		(SELECT OrganizationId, UserId FROM Auth.OrganizationUser WHERE UserId=@userId AND OrgRoleId=2) as OrganizationUser
		JOIN Auth.Organization ON OrganizationUser.OrganizationId=Organization.OrganizationId
		JOIN Shared.Project ON Project.OrganizationId=Organization.OrganizationId
		JOIN Shared.Customer ON Project.CustomerId=Customer.CustomerId
	) WHERE Organization.IsActive=1
		AND Customer.IsActive=1
		AND Project.IsActive=1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[GetProjectUsersByProjectId]
	@ProjectId int
AS
BEGIN 
	BEGIN TRANSACTION
	SELECT [UserId]
	FROM [Shared].[ProjectUser] 
	LEFT JOIN [Shared].[Project] ON [ProjectUser].ProjectId = Project.ProjectId
	LEFT JOIN [Shared].[Customer] ON [Customer].CustomerId = Project.CustomerId
	WHERE Customer.IsActive = 1 
	AND Project.IsActive = 1
	AND ProjectUser.ProjectId = @ProjectId
	COMMIT TRANSACTION
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [Shared].[UpdateProjectName]
	@projectId int,
	@name nvarchar(max)
AS
	UPDATE [Shared].[Project]
	SET Name = @name
	WHERE ProjectId = @projectId

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [TimeTracker].[CreateTimeEntry]
	@UserId nvarchar(40),
	@ProjectId int,
    @Date date,
    @Duration float,
    @Description nvarchar(120),
    @retId INT OUTPUT
AS
BEGIN
	SET XACT_ABORT ON
	INSERT INTO [TimeTracker].[TimeEntry]
			   ([UserId]
			   ,[ProjectId]
			   ,[Date]
			   ,[Duration]
			   ,[Description])
		 VALUES(@UserId
			   ,@ProjectId
			   ,@Date
			   ,@Duration
			   ,@Description);
	SET @retId = SCOPE_IDENTITY();
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [TimeTracker].[DeleteTimeEntry]
	@TimeEntryId int
AS
UPDATE [TimeTracker].[TimeEntry] 
	SET [IsActive] = 0 
    WHERE TimeEntryId = @TimeEntryId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [TimeTracker].[GetTimeEntriesByUserOverDateRange]
	@UserId [User].[UserTable] READONLY,
	@OrganizationId int,
	@StartingDate date,
	@EndingDate date
AS
SELECT [TimeEntryId] 
	  ,[User].[UserId] as UserId
	  ,[User].[FirstName] as FirstName
	  ,[User].[LastName] as LastName
      ,[ProjectId]
      ,[Date]
      ,[Duration]
      ,[Description]
	  ,[ApprovalState]
	  ,[ModSinceApproval]
  FROM [TimeTracker].[TimeEntry] LEFT JOIN [Auth].[User] on [TimeEntry].[UserId] = [User].[UserId]
  WHERE [User].[UserId] in (SELECT [userId] FROM @UserId)
  AND @OrganizationId = (SELECT [OrganizationId] FROM [Shared].[Project] WHERE ProjectId = [TimeEntry].ProjectId)
  AND [Date] >= @StartingDate
  AND [Date] <= @EndingDate
  AND [IsActive] = 1
  ORDER BY [Date] ASC
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [TimeTracker].[GetTimeEntriesOverDateRange]
	@OrganizationId int,
	@StartingDate date,
	@EndingDate date
AS
SELECT [TimeEntryId] 
	  ,[User].[UserId] as UserId
	  ,[User].[FirstName] as FirstName
	  ,[User].[LastName] as LastName
      ,[ProjectId]
      ,[Date]
      ,[Duration]
      ,[Description]
	  ,[ApprovalState]
	  ,[ModSinceApproval]
  FROM [TimeTracker].[TimeEntry] LEFT JOIN [Auth].[User] on [TimeEntry].[UserId] = [User].[UserId]
  WHERE @OrganizationId = (SELECT [OrganizationId] FROM [Shared].[Project] WHERE ProjectId = [TimeEntry].ProjectId)
  AND [Date] >= @StartingDate
  AND [Date] < @EndingDate
  AND [IsActive] = 1
  ORDER BY [Date] ASC
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [TimeTracker].[GetTimeEntryById]
	@timeEntryId int
AS
	SELECT [UserId],
		[ProjectId],
		[Date],
		[Duration],
		[Description],
		[ApprovalState],
		[ModSinceApproval]
	FROM [TimeTracker].[TimeEntry]
	WHERE [TimeEntryId] = @timeEntryId AND [IsActive] = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [TimeTracker].[SetTimeEntryApprovalStateById]
	@timeEntryId int,
	@approvalState int
AS
	UPDATE [TimeTracker].[TimeEntry]
	SET [ApprovalState] = @approvalState,
		[ModSinceApproval] = 0
	WHERE [TimeEntryId] = @timeEntryId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [TimeTracker].[UpdateTimeEntry]
	@TimeEntryId int,
    @ProjectId int,
	@Duration float,
	@Description nvarchar(120)
AS
UPDATE [TimeTracker].[TimeEntry]
   SET [ProjectId] = @ProjectId
      ,[Duration] = @Duration
      ,[Description] = @Description
	  ,[ModSinceApproval] = CASE WHEN [TimeEntry].ApprovalState = 0 THEN 0 ELSE 1 END
 WHERE TimeEntryId = @TimeEntryId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
Create PROCEDURE [User].[CreateInfo]
@Id NVARCHAR(40),
	@FirstName NVARCHAR(100),
	@LastName NVARCHAR(100),
    @Address NVARCHAR(100), 
    @City NVARCHAR(100), 
    @State NVARCHAR(100), 
    @Country NVARCHAR(100), 
    @ZipCode NVARCHAR(50),
	@Email NVARCHAR(100), 
    @PhoneNumber NVARCHAR(50),
	@DateOfBirth date
AS
BEGIN
	INSERT INTO [Auth].[User] (UserId, FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber, DateOfBirth)
	VALUES (@Id, @FirstName, @LastName, @Address, @City, @State, @Country, @ZipCode, @Email, @PhoneNumber, @DateOfBirth);
END
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [User].[GetActiveOrg]
	@UserId NVARCHAR(40)
AS
BEGIN
	SELECT [ActiveOrganizationId]
	FROM [Auth].[User]
	WHERE [Auth].[User].[Id] = @UserId	
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [User].[GetActiveSub]
	@UserId NVARCHAR(40)
AS
BEGIN
	SELECT [LastSubscriptionId]
	FROM [Auth].[User]
	WHERE [Auth].[User].[UserId] = @UserId	
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [User].[GetOrgList]
	@UserId NVARCHAR(40)
AS
BEGIN
	SELECT [O].OrganizationId, UserId, Name AS OrganizationName, OrgRoleId
	FROM [Auth].[OrganizationUser] AS [OU]
	INNER JOIN [Auth].[Organization] AS [O]
	ON [OU].[OrganizationId] = [O].[OrganizationId]
	WHERE [OU].[UserId] = @UserId AND [OU].[IsActive] = 1
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 

create procedure [User].[getUsersByOrganization]
@OrganizationId int,
@SubscriptionId int
as

SELECT [FirstName] ,LastName, ProductRoleId, [User].UserId
  FROM [Auth].[OrganizationUser] 
  left join [Auth].[User] on [OrganizationUser].[UserId]=[User].[UserId] 
left join(select  UserId, ProductRoleId from[Billing].[SubscriptionUser] where SubscriptionId=@SubscriptionId and IsActive=1 ) as  onroles on [User].UserId=onroles.UserId 
  where OrganizationId=@OrganizationId and OrganizationUser.IsActive = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
Create Procedure [User].[GetUserFromEmail]
	@email nvarchar(128)
AS
	Select [UserId]
      ,[FirstName]
      ,[LastName]
      ,[DateOfBirth]
      ,[Address]
      ,[City]
      ,[State]
      ,[Country]
      ,[ZipCode]
      ,[Email]
      ,[PhoneNumber]
      ,[PhoneExtension]
      ,[LastSubscriptionId] from [Auth].[User] where Email = @email
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [User].[getUsersByOrganization]
@OrganizationId int,
@SubscriptionId int
as

SELECT [FirstName] ,LastName, ProductRoleId, [User].UserId
  FROM [Auth].[OrganizationUser] 
  left join [Auth].[User] on [OrganizationUser].[UserId]=[User].[UserId] 
left join(select  UserId, ProductRoleId from[Billing].[SubscriptionUser] where SubscriptionId=@SubscriptionId and IsActive=1 ) as  onroles on [User].UserId=onroles.UserId 
  where OrganizationId=@OrganizationId and OrganizationUser.IsActive = 1
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [User].[GetUsersWithSubscriptionToProductInOrganization]
	@OrganizationId int,
	@ProductId int 
AS
SELECT [User].[UserId],
	   [User].[FirstName],
	   [User].[LastName]
	FROM [Auth].[User] 
	LEFT JOIN [Billing].[SubscriptionUser] 
		ON [User].[UserId] = [SubscriptionUser].[UserId]
	LEFT JOIN [Billing].[Subscription]
		ON [Subscription].SubscriptionId = SubscriptionUser.SubscriptionId
WHERE [Subscription].[SubscriptionId] = (
			SELECT [SubscriptionId] 
				FROM [Billing].[Subscription]
				LEFT JOIN [Billing].[SKU] 
					ON [SKU].[SKUId] = [Subscription].[SKUId]
				LEFT JOIN [Auth].[Organization]
					ON [Organization].[OrganizationId] = [Subscription].[OrganizationId]
				WHERE [Subscription].[OrganizationId] = @OrganizationId
				AND [SKU].[ProductId] = @ProductId
				AND [Organization].[IsActive] = 1
				AND [Subscription].IsActive = 1
				)
AND [SubscriptionUser].[IsActive] = 1

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [User].[ReadInfo]
	@UserId NVARCHAR(40)
AS
BEGIN
	SELECT [User].[UserId],
		   [User].[FirstName],
		   [User].[LastName],
		   [User].[DateOfBirth],
		   [User].[Address],
		   [User].[City],
		   [User].[State],
		   [User].[Country],
		   [User].[ZipCode],
		   [User].[Email],
		   [User].[PhoneNumber],
		   [User].[LastSubscriptionId]
	FROM [Auth].[User] AS [User]
	WHERE [UserId] = @UserId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE Procedure [User].[SetLastSub]
	@productId int,
	@userId nvarchar(40)
AS
UPDATE [Auth].[User] 
SET [LastSubscriptionId] = 
	(SELECT [SubscriptionId] FROM [Billing].[Subscription] 
	Left JOIN [Billing].[SKU] ON [Billing].[Subscription].[SKUId] = [SKU].[SKUId] 
	WHERE [ProductId] = @productId)
WHERE [UserId] = @userId
 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [User].[UpdateActiveOrg]
	@UserId NVARCHAR(40),
	@OrganizationId int
AS
BEGIN
	UPDATE [Auth].[User]
	SET [ActiveOrganizationId] = @OrganizationId
	WHERE [Id] = @UserId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [User].[UpdateActiveSub]
	@UserId NVARCHAR(40),
	@SubscriptionId int
AS
BEGIN
	UPDATE [Auth].[User]
	SET [LastSubscriptionId] = @SubscriptionId
	WHERE [UserId] = @UserId
END

 SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
CREATE PROCEDURE [User].[UpdateInfo]
	@Id NVARCHAR(40),
	@FirstName NVARCHAR(100),
	@LastName NVARCHAR(100),
    @Address NVARCHAR(100), 
    @City NVARCHAR(100), 
    @State NVARCHAR(100), 
    @Country NVARCHAR(100), 
    @ZipCode NVARCHAR(50),
    @PhoneNumber NVARCHAR(50),
	@DateOfBirth date
AS
BEGIN
	UPDATE [Auth].[User]
	SET [FirstName] = @FirstName, [LastName] = @LastName, [Address] = @Address, [City] = @City, [State] = @State, [Country] = @Country, [ZipCode] = @ZipCode, [PhoneNumber] = @PhoneNumber, [DateOfBirth] = @DateOfBirth
	WHERE [UserId] = @Id
END
