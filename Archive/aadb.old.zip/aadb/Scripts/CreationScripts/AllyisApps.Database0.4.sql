USE [AllyisApps.Database] 
GO 
 CREATE TABLE [Auth].[AccessCodes]
(
	[Code] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [OrgId] NVARCHAR(50) NOT NULL
)
GO

CREATE TABLE [Auth].[Organization]
(
	[OrganizationId] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    [Name] NVARCHAR(100) NOT NULL, 
    [SiteUrl] NVARCHAR(100) NULL, 
    [Address] NVARCHAR(100) NULL, 
    [City] NVARCHAR(100) NULL, 
    [State] NVARCHAR(100) NULL, 
    [Country] NVARCHAR(100) NULL, 
    [ZipCode] NVARCHAR(50) NULL, 
    [PhoneNumber] NVARCHAR(50) NULL, 
    [AccessCode] NVARCHAR(10) NULL, 
    [DateCreated] DATETIME NOT NULL, 
    [IsActive] BIT NOT NULL DEFAULT 1, 
    [Subdomain] NVARCHAR(40) NOT NULL UNIQUE
)

GO

CREATE TABLE [Auth].[OrgRole]
(
	[OrgRoleId] INT NOT NULL PRIMARY KEY,
	[Name] NVARCHAR(100) NOT NULL, 
    [PermissionAdmin] BIT NOT NULL DEFAULT 0
)
GO

  
CREATE TABLE [Billing].[Product]
(
	[ProductId] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[Name] NVARCHAR(128) NOT NULL, 
    [Description] NVARCHAR(MAX) NULL
)
GO

CREATE INDEX [IX_Product_Name] ON [Billing].[Product]([Name])
GO

CREATE TABLE [Lookup].[Country]
(
	[CountryId] INT NOT NULL PRIMARY KEY IDENTITY(1,1), 
	[Code] NCHAR(2) NOT NULL UNIQUE,
    [Name] NVARCHAR(100) NOT NULL DEFAULT ''
)

GO

CREATE INDEX [IX_Country_Code] ON [Lookup].[Country] ([Code])
GO

CREATE TABLE [Auth].[Invitation]
(
	[InvitationId] INT NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [Email] NVARCHAR(40) NOT NULL, 
    [FirstName] NVARCHAR(40) NOT NULL, 
    [LastName] NVARCHAR(40) NOT NULL, 
    [DateOfBirth] NVARCHAR(40) NOT NULL, 
    [OrganizationId] INT NOT NULL,
	[AccessCode] NVARCHAR(50) NOT NULL, 
    CONSTRAINT [FK_Invitation_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [Auth].[Organization]([OrganizationId])
)

 GO 

 CREATE TABLE [Billing].[SKU]
(
	[SKUId] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[ProductId] INT NOT NULL,
	[Name] NVARCHAR(128) NOT NULL,
	[Price] MONEY NOT NULL,
    [UserLimit] INT NOT NULL, 
    [BillingFrequency] NVARCHAR(50) NOT NULL, 
    [Tier] NCHAR(50) NOT NULL, 
    CONSTRAINT [FK_SKUs_Product] FOREIGN KEY ([ProductId]) REFERENCES [Billing].[Product]([ProductId])
)
GO

CREATE INDEX [IX_SKU_Name] ON [Billing].[SKU]([Name])
 GO 


CREATE TABLE [Billing].[Subscription]
(
	[SubscriptionId] INT PRIMARY KEY IDENTITY (1,1),
	[OrganizationId] INT NOT NULL,
	[SKUId] INT NOT NULL,
	[NumberOfUsers] INT NOT NULL , 
	[CreatedDate] DATETIME DEFAULT GETDATE() NOT NULL,
	[IsActive] BIT DEFAULT 1 NOT NULL,

    CONSTRAINT [FK_OrganizationSubscription_Organization] FOREIGN KEY ([OrganizationId]) REFERENCES [Auth].[Organization]([OrganizationId]),
	CONSTRAINT [FK_OrganizationSubscription_SKU] FOREIGN KEY ([SKUId]) REFERENCES [Billing].[SKU]([SKUId]),
)
GO

 CREATE TABLE [Auth].[User]
(
	[UserId] NVARCHAR(40) NOT NULL PRIMARY KEY,
    [FirstName] NVARCHAR(100) NOT NULL, 
    [LastName] NVARCHAR(100) NOT NULL, 
    [DateOfBirth] DATE NULL, 
    [Address] NVARCHAR(100) NULL, 
    [City] NVARCHAR(100) NULL, 
    [State] NVARCHAR(100) NULL, 
    [Country] NVARCHAR(100) NULL, 
    [ZipCode] NVARCHAR(50) NULL, 
    [Email] NVARCHAR(100) NOT NULL UNIQUE, 
    [PhoneNumber] NVARCHAR(50) NULL, 
    [PhoneExtension] NVARCHAR(50) NULL,
	[LastSubscriptionId] INT NULL, 
    
    CONSTRAINT [FK_User_Subscription] FOREIGN KEY ([LastSubscriptionId]) REFERENCES [Billing].[Subscription] ([SubscriptionId])
	ON DELETE SET NULL
	ON UPDATE NO ACTION
)
GO

CREATE UNIQUE INDEX [IX_User_EMail] ON [Auth].[User] ([Email])


CREATE TABLE [Auth].[Logging]
(
	[LoggingId] BIGINT NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [EntityName] NVARCHAR(128) NOT NULL, 
	[UserId] NVARCHAR(40) NOT NULL,
    [Action] NVARCHAR(128) NOT NULL,
	[DateModified] DATETIME NOT NULL,
	[DataBefore] NVARCHAR(512) NULL,
	[DataAfter] NVARCHAR(512) NULL,
	CONSTRAINT [FK_Logging_User] FOREIGN KEY ([UserId]) REFERENCES [Auth].[User]([UserId]),
)


 GO 
CREATE TABLE [Auth].[OrganizationUser]
(
    [UserId] NVARCHAR(40) NOT NULL, 
    [OrganizationId] INT NOT NULL, 
    [OrgRoleId] INT NOT NULL,
	[IsActive] BIT DEFAULT 1 NOT NULL,
    [DateAdded] DATETIME NOT NULL, 
    CONSTRAINT [FK_OrganizationUser_Organization] FOREIGN KEY ([OrganizationId]) REFERENCES [Auth].[Organization]([OrganizationId]),
	CONSTRAINT [FK_OrganizationUser_User] FOREIGN KEY ([UserId]) REFERENCES [Auth].[User]([UserId]),
	CONSTRAINT [FK_OrganizationUser_OrgRole] FOREIGN KEY ([OrgRoleId]) REFERENCES [Auth].[OrgRole]([OrgRoleId]),
	CONSTRAINT [PK_Organization_User] PRIMARY KEY NONCLUSTERED ([UserId], [OrganizationId]) 
)
GO

CREATE CLUSTERED INDEX [IX_UserId_OrganizationId] ON [Auth].[OrganizationUser]([UserId], [OrganizationId]);

GO


CREATE TABLE [Auth].[ProductRole]
(
	[ProductRoleId] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[ProductId] int NOT NULL,
	[Name] NVARCHAR(100) NOT NULL,
	[PermissionAdmin] BIT NOT NULL DEFAULT 0, 
    CONSTRAINT [FK_ProductRole_Product] FOREIGN KEY ([ProductId]) REFERENCES [Billing].[Product]([ProductId]),
	
)

GO

CREATE INDEX [IX_ProductRole_ProductId] ON [Auth].[ProductRole] ([ProductId])

 GO 






CREATE INDEX [IX_Subscription_SKUId] ON [Billing].[Subscription] ([SKUId])

 GO 


CREATE TABLE [Billing].[SubscriptionUser]
(
    [SubscriptionId] INT NOT NULL,
    [UserId] NVARCHAR(40) NOT NULL,
	[ProductRoleId] INT NOT NULL,
	[IsActive] BIT DEFAULT 1 NOT NULL,

	[DateAdded] DATE NOT NULL, 
    CONSTRAINT [PK_SKU_USER] PRIMARY KEY NONCLUSTERED ([SubscriptionId], [UserId]),
    CONSTRAINT [FK_SubscriptionUser_Subscription] FOREIGN KEY ([SubscriptionId]) REFERENCES [Billing].[Subscription]([SubscriptionId]),
	CONSTRAINT [FK_SubscriptionUser_User] FOREIGN KEY ([UserId]) REFERENCES [Auth].[User]([UserId]) ON DELETE CASCADE,
	CONSTRAINT [FK_SubscriptionUser_ProductRole] FOREIGN KEY ([ProductRoleId]) REFERENCES [Auth].[ProductRole]([ProductRoleId]),
	CONSTRAINT SubscriptionUserNoDuplicates UNIQUE NONCLUSTERED(UserId, SubscriptionId)
)
GO

CREATE CLUSTERED INDEX [IX_SubscriptionUser_SubscriptionId] ON [Billing].[SubscriptionUser]([SubscriptionId]);

 GO 
CREATE TABLE [Shared].[Customer]
(
	[CustomerId] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    [Name] NVARCHAR(50) NOT NULL,
	[ContactEmail] NVARCHAR(50) NULL, 
    [Address] NVARCHAR(100) NULL, 
    [City] NVARCHAR(100) NULL, 
    [State] NVARCHAR(100) NULL, 
    [Country] NVARCHAR(100) NULL, 
    [ZipCode] NVARCHAR(50) NULL, 
    [ContactPhoneNumber] NVARCHAR(50) NULL, 
	[FaxNumber] NVARCHAR(50) NULL,
	[Website] NVARCHAR(50) NULL,
	[EIN] NVARCHAR(50) NULL,
    [DateCreated] DATETIME, 
	[OrganizationId] INT NOT NUll,
	[IsActive] BIT DEFAULT(1) NOT NULL

	CONSTRAINT [FK_OrganizationUser_Organization] FOREIGN KEY ([OrganizationId]) REFERENCES [Auth].[Organization]([OrganizationId]),

)

 GO 

CREATE TABLE [Lookup].[State]
(
	[StateId] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[Code] NCHAR(2) NOT NULL,
    [Name] NVARCHAR(100) NOT NULL DEFAULT '', 
    CONSTRAINT [FK_States_Country] FOREIGN KEY ([Code]) REFERENCES [Lookup].[Country]([Code])
)

GO

CREATE INDEX [IX_State_Code] ON [Lookup].[State] ([Code])


 GO 


CREATE TABLE [Shared].[Project](
	[ProjectId] [int] NOT NULL PRIMARY KEY IDENTITY(1,1),
	[OrganizationId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
	[IsActive] [int] DEFAULT 1 NOT NULL,
	[Created] [datetime] DEFAULT CURRENT_TIMESTAMP

 CONSTRAINT [FK_Shared.Project_Customer] FOREIGN KEY([CustomerId]) REFERENCES [Shared].[Customer] ([CustomerId]),
 CONSTRAINT [FK_Shared.Project_Organization] FOREIGN KEY([OrganizationId]) REFERENCES [Auth].[Organization] ([OrganizationId])
)
 GO 

CREATE TABLE [TimeTracker].[Approval]
(
	[ApprovalState] INT NOT NULL PRIMARY KEY, 
    [StateName] NVARCHAR(50) NOT NULL
)
GO

CREATE TABLE [TimeTracker].[TimeEntry](
	[TimeEntryId] [int] NOT NULL PRIMARY KEY IDENTITY(1,1),
	[UserId] [nvarchar](40) NOT NULL,
	[ProjectId] [int] NOT NULL,
	[Date] [date] NOT NULL,
	[Duration] [float] NOT NULL,
	[Description] [nvarchar](120) NULL,
	[IsActive] [bit] NOT NULL DEFAULT 1,
	[ApprovalState] [int] NOT NULL DEFAULT 0,
	[ModSinceApproval] [bit] NOT NULL DEFAULT 0
	
	CONSTRAINT [FK_TimeEntry_UserId] FOREIGN KEY([UserId]) REFERENCES [Auth].[User] ([UserId]),
	CONSTRAINT [FK_TimeEntry_ApprovalState] FOREIGN KEY([ApprovalState]) REFERENCES [TimeTracker].[Approval] ([ApprovalState])
)
GO

CREATE INDEX [IX_TimeTracker_TimeEntryId] ON [TimeTracker].[TimeEntry]([TimeEntryId])
 GO 

 CREATE TABLE [Billing].[BillingHistory]
(
	[Date] DATETIME NOT NULL PRIMARY KEY, 
    [Description] NVARCHAR(MAX) NOT NULL, 
    [OrganizationId] INT NOT NULL, 
    [UserId] NVARCHAR(50) NOT NULL, 
    [ProductId] INT NULL
)

GO

CREATE TABLE [Billing].[CustomerSubscriptionPlan]
(
	[CustomerId] NVARCHAR(50) NOT NULL , 
    [SubscriptionID] NCHAR(50) NOT NULL PRIMARY KEY, 
    [AccountID] NCHAR(50) NOT NULL, 
	[NumberofUsers] int NOT NULL, 
	[Price] INT NOT NULL, 
    [ProductId] INT NOT NULL, 
    [IsActive] INT NOT NULL, 
    [OrganizationId] INT NOT NULL
	) 

GO


CREATE TABLE [Billing].[OrganizationCustomer]
(
	OrgId INT NOT NULL PRIMARY KEY, 
	CustomerId NVARCHAR(50) NOT NULL UNIQUE
)
GO

CREATE TABLE [Shared].[ProjectUser]
(
    [ProjectId] INT NOT NULL,
	[UserId] NVARCHAR(40) NOT NULL,  
	[IsActive] BIT DEFAULT 1 NOT NULL,
    [DateAdded] DATETIME NOT NULL, 

    CONSTRAINT [FK_OrganizationUser_ProjectUser] FOREIGN KEY ([ProjectId]) REFERENCES [Auth].[Organization]([OrganizationId]),
	CONSTRAINT [FK_OrganizationUser_User] FOREIGN KEY ([UserId]) REFERENCES [Auth].[User]([UserId])
)
GO