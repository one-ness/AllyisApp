USE [AllyisApps.Database] 
GO 
﻿
--------------- Insert Global Roles -----------------------
INSERT INTO [Auth].[OrgRole] (OrgRoleId, Name) VALUES (1, 'Member');
INSERT INTO [Auth].[OrgRole] (OrgRoleId, Name, PermissionAdmin) VALUES (2, 'Owner', 1);
GO

--------------- Insert TimeTracker Product------------------
BEGIN TRANSACTION
DECLARE @LastIdTT INT;
INSERT INTO [Billing].[Product] (Name)
VALUES ('TimeTracker');
SET @LastIdTT = SCOPE_IDENTITY();

--------------- Insert TimeTracker SKU List ---------------------------

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdTT, 'TimeTracker - Free', '0.00', 5, 'Free', 'Free')

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdTT, 'TimeTracker - Basic', '10.00', 20, 'Monthly', 'Basic')

--------------- Insert TimeTracker Roles ------------------
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdTT, 'None');
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdTT, 'User');
INSERT INTO [Auth].[ProductRole] (ProductId, Name, PermissionAdmin) VALUES (@LastIdTT, 'Manager', 1);

COMMIT TRANSACTION

---------------- Insert Meeting Product -------------------
BEGIN TRANSACTION

DECLARE @LastIdM INT;
INSERT INTO [Billing].[Product] (Name)
VALUES ('Meeting');
SET @LastIdM = SCOPE_IDENTITY();

---------------- Insert Meeting SKU List -------------------

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdM, 'Meeting - Free', '0.00', 5, 'Free', 'Free')

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdM, 'Meeting - Basic', '5.00', 25, 'Monthly', 'Basic')

---------------- Insert Meeting SKU List -------------------
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdM, 'None');
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdM, 'Member');
INSERT INTO [Auth].[ProductRole] (ProductId, Name, PermissionAdmin) VALUES (@LastIdM, 'Owner', 1);

COMMIT TRANSACTION

---------------- Insert timeSheet Product -------------------
BEGIN TRANSACTION

DECLARE @LastIdts INT;
INSERT INTO [Billing].[Product] (Name)
VALUES ('timeSheet');
SET @LastIdts = SCOPE_IDENTITY();

---------------- Insert timeSheet SKU List -------------------

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdts, 'timeSheet - Free', '0.00', 5, 'Free', 'Free')

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdts, 'timeSheet - Basic', '20.00', 15, 'Monthly', 'Basic')

---------------- Insert timeSheet SKU List -------------------
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdts, 'None');
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdts, 'Member');
INSERT INTO [Auth].[ProductRole] (ProductId, Name, PermissionAdmin) VALUES (@LastIdts, 'Owner', 1);

COMMIT TRANSACTION


---------------- Insert Invoice Product -------------------
BEGIN TRANSACTION

DECLARE @LastIdInv INT;
INSERT INTO [Billing].[Product] (Name)
VALUES ('Invoice');
SET @LastIdInv = SCOPE_IDENTITY();

---------------- Insert Invoice SKU List -------------------

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdInv, 'Invoice - Free', '0.00', 5, 'Free', 'Free')

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdInv, 'Invoice - Basic', '20.00', 15, 'Monthly', 'Basic')

---------------- Insert Invoice SKU List -------------------
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdInv, 'None');
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdInv, 'Member');
INSERT INTO [Auth].[ProductRole] (ProductId, Name, PermissionAdmin) VALUES (@LastIdInv, 'Owner', 1);

COMMIT TRANSACTION


---------------- Insert Expense Product -------------------
BEGIN TRANSACTION

DECLARE @LastIdExpense INT;
INSERT INTO [Billing].[Product] (Name)
VALUES ('Expense');
SET @LastIdExpense = SCOPE_IDENTITY();

---------------- Insert Expense SKU List -------------------

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdExpense, 'Expense - Free', '0.00', 5, 'Free', 'Free')

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdExpense, 'Expense - Basic', '20.00', 15, 'Monthly', 'Basic')

---------------- Insert Expense SKU List -------------------
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdExpense, 'None');
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdExpense, 'Member');
INSERT INTO [Auth].[ProductRole] (ProductId, Name, PermissionAdmin) VALUES (@LastIdExpense, 'Owner', 1);

COMMIT TRANSACTION


---------------- Insert Tasks Product -------------------
BEGIN TRANSACTION

DECLARE @LastIdTasks INT;
INSERT INTO [Billing].[Product] (Name)
VALUES ('Tasks');
SET @LastIdTasks = SCOPE_IDENTITY();

---------------- Insert Tasks SKU List -------------------

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdTasks, 'Tasks - Free', '0.00', 5, 'Free', 'Free')

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdTasks, 'Tasks - Basic', '20.00', 15, 'Monthly', 'Basic')

---------------- Insert Tasks SKU List -------------------
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdTasks, 'None');
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdTasks, 'Member');
INSERT INTO [Auth].[ProductRole] (ProductId, Name, PermissionAdmin) VALUES (@LastIdTasks, 'Owner', 1);

COMMIT TRANSACTION


---------------- Insert CRM Product -------------------
BEGIN TRANSACTION

DECLARE @LastIdC INT;
INSERT INTO [Billing].[Product] (Name)
VALUES ('CRM');
SET @LastIdC = SCOPE_IDENTITY();

---------------- Insert CRM SKU List -------------------

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdC, 'CRM - Free', '0.00', 5, 'Free', 'Free')

INSERT INTO [Billing].[SKU] (ProductId, Name, Price, UserLimit, BillingFrequency, Tier)
VALUES (@LastIdC, 'CRM - Basic', '20.00', 15, 'Monthly', 'Basic')

---------------- Insert CRM SKU List -------------------
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdC, 'None');
INSERT INTO [Auth].[ProductRole] (ProductId, Name) VALUES (@LastIdC, 'Member');
INSERT INTO [Auth].[ProductRole] (ProductId, Name, PermissionAdmin) VALUES (@LastIdC, 'Owner', 1);

COMMIT TRANSACTION

BEGIN TRANSACTION
INSERT INTO [TimeTracker].[Approval] (ApprovalState, StateName) VALUES (0, 'NoApprovalState');
INSERT INTO [TimeTracker].[Approval] (ApprovalState, StateName) VALUES (1, 'NotApproved');
INSERT INTO [TimeTracker].[Approval] (ApprovalState, StateName) VALUES (2, 'Approved');
COMMIT TRANSACTION

--------------- Insert My Defaults ------------------------
/*
BEGIN TRANSACTION
--Migration Entry
--INSERT INTO [dbo].[__MigrationHistory] (MigrationId, ContextKey, Model, ProductVersion) VALUES ('201506122005496_InitialCreate', 'AllyisApps.Models.ApplicationDbContext', 0x1F8B0800000000000400DD5CDB6EE436127D5F60FF41D05376E1B47CD919CC1AED044EDBCE1A3BBE60DA13E46DC096D86D61244A1129C7C6225F96877C527E618B1275E345976EB9BB1D0C30B0C8E2A962B148168BC5FEF3F73FA6DF3F8781F58413EA47E4CC3E9A1CDA16266EE4F9647566A76CF9ED07FBFBEFFEFEB7E9A5173E5B3F1574279C0E5A127A663F32169F3A0E751F7188E824F4DD24A2D1924DDC2874901739C78787FF768E8E1C0C10366059D6F4534A981FE2EC033E67117171CC5214DC441E0EA828879A79866ADDA210D318B9F8CC3E0F82179F9EC7319DE4C4B6751EF8080499E360695B8890882106629E7EA678CE9288ACE63114A0E0E125C640B74401C542FCD38ABC6F4F0E8F794F9CAA6101E5A69445E140C0A313A11A476EBE9682ED5275A0BC4B50327BE1BDCE1478665F7B382BFA1405A00099E1E92C4838F1997D53B238A7F12D6693A2E12487BC4A00EED728F93AA9231E58BDDB1D94A6743C39E4FF0EAC591AB034C16704A72C41C181759F2E02DFFD2F7E7988BE62727672B4589E7C78F71E7927EFFF854FDED57B0A7D05BA460114DD27518C13900D2FCBFEDB96D36CE7C80DCB66B536B956C0966056D8D60D7AFE88C98A3DC27C39FE605B57FE33F68A12615C9F890F93081AB12485CFDB3408D022C065BDD3CA93FFDFC2F5F8DDFB51B8DEA2277F950DBDC41F264E02F3EA130EB25AFAE8C7F9F46A8CF7174176954421FF6EDA575EFB651EA589CB3B1319491E50B2C2AC29DDD4A98CB7974973A8F1CDBA40DD7FD3E692AAE6AD25E51D5A6726142CB63D1B0A795F976F6F8B83AD07062F332DAE91368353F6AA89D4F8C0AA482AC339EA6B38043AF4575E072F43E407232C843DB8800BB2F4931097BDFC2102B34364B0CCF788525807BCFF20FAD8223AFC3982E873ECA60998E79CA1307E756EF78F11C1B769B8E056BF3D5EA30DCDC3AFD1157259945C12DE6A63BC8F91FB354AD925F12E10C39F995B00F2CF073FEC0F308A38E7AE8B29BD0263C6DE2C020FBB00BC26ECE478301C5F9F76ED88CC02E4877A4F445A49BF14A49537A2A7503C120399CE2B6913F563B4F2493F510B52B3A83945A7A8826CA8A81CAC9FA482D22C6846D029674E359A9F978DD0F88E5E06BBFF9EDE669BB7692DA8A9710E2B24FE11139CC032E6DD23C67042AA11E8B36EECC259C8868F337DF5BD29E3F4130AD2B159AD351BB24560FCD990C1EEFF6CC8C484E227DFE35E498FE34F410CF0BDE8F527ABEE392749B6EDE9D0E8E6B6996F670D304D97734A23D7CF668126F025C2164DF9C187B3BA6318796FE43808740C0CDDE75B1E9440DF6CD9A8EEC8050E30C3D6B99B07066788BAC853D5081DF2060856ECA81AC1AA784853B87F2A3CC1D271C21B217E08A230537DC2D469E113D78F51D0A925A965CF2D8CF7BDE421D75CE01813CEB053137D98EBC31F5C80928F34285D1A9A3A358B6B374483D76A1AF32E17B61A77252AB1159BECF09D0D7629FCB75731CC768D6DC138DB55D2470063286F17062ACE2A7D0D403EB8EC9B814A272683810A976A2B06DAD4D80E0CB4A9923767A0F911B5EFF84BE7D57D33CFE64179FBDB7AABBA76609B0D7DEC9969E6BE27B461D00227AA795E2C78257E669AC319C829CE6754B8BAB28970F03966CD904DE5EF6AFD50A71D4436A236C0CAD03A40C525A002A44CA801C215B1BC56E984173100B688BBB5C28AB55F82ADD9808A5DBF0CAD119AAF4C65E3EC75FA287B565A8362E4BD0E0B351C8D41C88B57B3E33D94628ACBAA8AE9E30B0FF1866B1D1383D1A2A00ECFD5A0A4A233A36BA930CD6E2DE91CB2212ED9465A92DC2783968ACE8CAE2561A3DD4AD2380503DC828D54D4DCC2479A6C45A4A3DC6DCABAA993A7488982A963C8A59ADEA038F6C9AA965B254AAC799E5835FB763E3CE528CC311C976A328F4A694B4E2C4AD00A4BB5C01A24BDF213CA2E10430BC4E33C332F54C8B47BAB61F92F58D6B74F75108B7DA0A0E67F0BD353AEEE1B5BADEA8B08882BE860C81D9A2C8AAE197E7D738BA7BAA100259AC0FD2C0AD29098FD2B73EBFCFAAEDE3E2F5111A68E24BFE23F29CA52BCDCA6E67B8D8B3A27C619A3D27B597F9CCC10266D17BE675DDF267FD48C5284A7EA28A690D5CEC6CDE4C60C192BD9411C3E549D08AF33AB44564A1D40140DC4A825362860B5BAFEA8CDDC933A66B3A63FA29460528794AA0648594F23690859AF580BCFA0513D457F0E6AE2481D5DADED8FAC4921A9436BAAD7C0D6C82CD7F547D56499D48135D5FDB1AB9413790DDDE37DCB786C5977E3CA0FB69BED5C068CD75910C7D9F86AF7F775A05AF1402C7143AF8089F2BD3426E3E96E5D63CAC3199B199301C3BCEE342EBE9BCB4EEB6DBD19B3719BDD58DADB6EF3CD78C34CF6550D4339DBC92425F7F28C279DE5A6E25CD5FD78463968E524B655A811B6F517CA7038E10493F92FC12CF0315FC40B821B44FC25A62CCFE0B08F0F8F8EA50738FBF318C6A1D40B34E752D38B98E6986D21198B3CA1C47D44899A1AB1C183910A54893A5F130F3F9FD9FFCB5A9D66010CFE57567C605DD3CFC4FF25858A8724C5D66F6AAAE73809F4ED27AC3D7DEED05FABD73F7FC99B1E587709CC9853EB50D2E53A23DC7C0431489ABCE906D2ACFD34E2ED4EA8C6CB032DAA3421D67F68B0F0D9288F0C0A29BF09D1F33F868AA67D48B011A2E6B1C05878A3A8D0F418601D2CE343000F3E59F610605867F50F03D611CDF828C027C3C1E42701FD97A1A2E50EB71ACD91681B4B52A6E7CE94EA8DF22B77BD372999D71B4D7435BB7A00DC0619D46B58C61B4B3E1E6D77D4E4168F86BD4BD37EF584E27DC921AEB23B769B3ABCCD6CE1963BA1BF5492F01EA4B569D274769F0ABC6D5B338571F73C9F7258C2EF9E199B48DEDA7D5AEFB68DCD14E6DD73631B94BCBB67B6B6ABFD73C796D67B0BDD792AAE9A5564B88ED1C582BB526DF3C0399CF017111841EE51E62F24F5B95D6D79A91D0C2B123353735299CC5899380A5F85A29DEDB0BE8A0DBFB5B382A69DAD2115B38DB758FF5B790B9A76DE8604C75D24096B530C7589DB1DEB585B06D45B4A0A6EF4A42307BDCB676DBD5B7F4B39C0A328A5317B0C77C46F27E57714958C397506A4F8AAD7BDB077D67E5111F66FEAAF2A08FEFB8A04BB8D5DB3A4B926CBA8D8BC25890A122942738319F2604B3D4F98BF442E836A1E63CE9E7867713B7ED3B1C0DE35B94B599C32E8320E174123E0C59D8036FE591E7353E6E95D9CFD5AC9185D00317D1E9BBF233FA47EE095725F6962420608EE5D88882E1F4BC623BBAB9712E936223D8184FA4AA7E80187710060F48ECCD1135E473630BF8F7885DC972A026802E91E88A6DAA7173E5A2528A402A36A0F9F60C35EF8FCDDFF01B2E819C558540000, '6.1.1-30610');
--GO

--Password for all users is P@ssw0rd
--10 Users
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 'v-trcol@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol1@microsoft.com');
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb1', 'v-trcol2@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol2@microsoft.com');
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb2', 'v-trcol3@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol3@microsoft.com');
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb3', 'v-trcol4@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol4@microsoft.com');
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb4', 'v-trcol5@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol5@microsoft.com');
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb5', 'v-trcol6@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol6@microsoft.com');
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb6', 'v-trcol7@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol7@microsoft.com');
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb7', 'v-trcol8@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol8@microsoft.com');
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb8', 'v-trcol9@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol9@microsoft.com');
INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, SecurityStamp, PhoneNumber, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEndDateUtc, LockoutEnabled, AccessFailedCount, UserName)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb9', 'v-trcol10@microsoft.com', 1, 'AP17iQI9BztKDcYRoOZXGRuY9GQYH0Gdz9SNoYEMWpuaSQPfnJQBtOjHStIT+HLHQQ==', '95a22a5b-bd26-4edb-8cb2-7c6f06943090' , NULL, 0, 0, NULL, 1, 0, 'v-trcol10@microsoft.com');

INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 'Travis', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol@microsoft.com', '1234567890');
INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb1', 'Travis2', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol2@microsoft.com', '1234567890');
INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb2', 'Travis3', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol3@microsoft.com', '1234567890');
INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb3', 'Travis4', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol4@microsoft.com', '1234567890');
INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb4', 'Travis5', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol5@microsoft.com', '1234567890');
INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb5', 'Travis6', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol6@microsoft.com', '1234567890');
INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb6', 'Travis7', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol7@microsoft.com', '1234567890');
INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb7', 'Travis8', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol8@microsoft.com', '1234567890');
INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb8', 'Travis9', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol9@microsoft.com', '1234567890');
INSERT INTO [Auth].[User] ([UserId], FirstName, LastName, [Address], City, [State], Country, ZipCode, Email, PhoneNumber)
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb9', 'Travis10', 'Coleman', 'Address', 'City', 'Washington', 'United States', 98168, 'v-trcol10@microsoft.com', '1234567890');
GO

--10 Organizations
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org1', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access1');
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org2', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access2');
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org3', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access3');
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org4', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access4');
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org5', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access5');
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org6', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access6');
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org7', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access7');
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org8', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access8');
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org9', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access9');
INSERT INTO [Auth].[Organization] ([Name], [SiteUrl], [Address], [City], [State], [Country], [ZipCode], [PhoneNumber], [AccessCode])
VALUES ('Org10', 'Site', 'Address', 'City', 'Washington', 'United States', 98168, NULL, 'Access10');
GO

--10 Organization Owners
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 1, 2, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb1', 2, 2, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb2', 3, 2, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb3', 4, 2, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb4', 5, 2, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb5', 6, 2, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb6', 7, 2, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb7', 8, 2, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb8', 9, 2, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb9', 10, 2, 1);

--20 Organization Users
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 2, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 3, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 4, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 5, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 6, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 7, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 8, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 9, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb0', 10, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb1', 3, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb2', 4, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb3', 5, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb4', 6, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb5', 7, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb6', 8, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb7', 9, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb8', 10, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb9', 1, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb2', 2, 1, 1);
INSERT INTO [Auth].[OrganizationUser] ([UserId], [OrganizationId], [OrgRoleId], [IsActive])
VALUES ('5b44f982-2c0f-4294-b31c-535fe56a8bb3', 3, 1, 1);

COMMIT TRANSACTION
*/
--------------- Insert Country List -----------------------

INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('US', 'United States');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CA', 'Canada');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AF', 'Afghanistan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AL', 'Albania');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('DZ', 'Algeria');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('DS', 'American Samoa');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AD', 'Andorra');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AO', 'Angola');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AI', 'Anguilla');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AQ', 'Antarctica');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AG', 'Antigua and/or Barbuda');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AR', 'Argentina');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AM', 'Armenia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AW', 'Aruba');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AU', 'Australia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AT', 'Austria');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AZ', 'Azerbaijan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BS', 'Bahamas');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BH', 'Bahrain');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BD', 'Bangladesh');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BB', 'Barbados');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BY', 'Belarus');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BE', 'Belgium');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BZ', 'Belize');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BJ', 'Benin');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BM', 'Bermuda');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BT', 'Bhutan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BO', 'Bolivia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BA', 'Bosnia and Herzegovina');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BW', 'Botswana');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BV', 'Bouvet Island');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BR', 'Brazil');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('IO', 'British lndian Ocean Territory');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BN', 'Brunei Darussalam');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BG', 'Bulgaria');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BF', 'Burkina Faso');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('BI', 'Burundi');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KH', 'Cambodia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CM', 'Cameroon');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CV', 'Cape Verde');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KY', 'Cayman Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CF', 'Central African Republic');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TD', 'Chad');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CL', 'Chile');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CN', 'China');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CX', 'Christmas Island');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CC', 'Cocos (Keeling) Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CO', 'Colombia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KM', 'Comoros');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CG', 'Congo');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CK', 'Cook Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CR', 'Costa Rica');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('HR', 'Croatia (Hrvatska)');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CU', 'Cuba');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CY', 'Cyprus');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CZ', 'Czech Republic');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('DK', 'Denmark');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('DJ', 'Djibouti');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('DM', 'Dominica');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('DO', 'Dominican Republic');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TP', 'East Timor');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('EC', 'Ecuador');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('EG', 'Egypt');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SV', 'El Salvador');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GQ', 'Equatorial Guinea');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ER', 'Eritrea');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('EE', 'Estonia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ET', 'Ethiopia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('FK', 'Falkland Islands (Malvinas)');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('FO', 'Faroe Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('FJ', 'Fiji');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('FI', 'Finland');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('FR', 'France');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('FX', 'France, Metropolitan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GF', 'French Guiana');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PF', 'French Polynesia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TF', 'French Southern Territories');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GA', 'Gabon');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GM', 'Gambia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GE', 'Georgia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('DE', 'Germany');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GH', 'Ghana');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GI', 'Gibraltar');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GR', 'Greece');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GL', 'Greenland');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GD', 'Grenada');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GP', 'Guadeloupe');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GU', 'Guam');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GT', 'Guatemala');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GN', 'Guinea');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GW', 'Guinea-Bissau');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GY', 'Guyana');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('HT', 'Haiti');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('HM', 'Heard and Mc Donald Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('HN', 'Honduras');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('HK', 'Hong Kong');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('HU', 'Hungary');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('IS', 'Iceland');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('IN', 'India');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ID', 'Indonesia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('IR', 'Iran (Islamic Republic of)');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('IQ', 'Iraq');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('IE', 'Ireland');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('IL', 'Israel');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('IT', 'Italy');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CI', 'Ivory Coast');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('JM', 'Jamaica');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('JP', 'Japan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('JO', 'Jordan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KZ', 'Kazakhstan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KE', 'Kenya');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KI', 'Kiribati');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KP', 'Korea, Democratic People''s Republic of');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KR', 'Korea, Republic of');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('XK', 'Kosovo');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KW', 'Kuwait');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KG', 'Kyrgyzstan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LA', 'Lao People''s Democratic Republic');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LV', 'Latvia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LB', 'Lebanon');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LS', 'Lesotho');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LR', 'Liberia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LY', 'Libyan Arab Jamahiriya');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LI', 'Liechtenstein');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LT', 'Lithuania');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LU', 'Luxembourg');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MO', 'Macau');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MK', 'Macedonia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MG', 'Madagascar');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MW', 'Malawi');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MY', 'Malaysia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MV', 'Maldives');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ML', 'Mali');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MT', 'Malta');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MH', 'Marshall Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MQ', 'Martinique');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MR', 'Mauritania');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MU', 'Mauritius');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TY', 'Mayotte');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MX', 'Mexico');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('FM', 'Micronesia, Federated States of');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MD', 'Moldova, Republic of');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MC', 'Monaco');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MN', 'Mongolia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ME', 'Montenegro');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MS', 'Montserrat');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MA', 'Morocco');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MZ', 'Mozambique');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MM', 'Myanmar');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NA', 'Namibia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NR', 'Nauru');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NP', 'Nepal');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NL', 'Netherlands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AN', 'Netherlands Antilles');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NC', 'New Caledonia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NZ', 'New Zealand');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NI', 'Nicaragua');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NE', 'Niger');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NG', 'Nigeria');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NU', 'Niue');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NF', 'Norfork Island');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('MP', 'Northern Mariana Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('NO', 'Norway');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('OM', 'Oman');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PK', 'Pakistan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PW', 'Palau');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PA', 'Panama');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PG', 'Papua New Guinea');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PY', 'Paraguay');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PE', 'Peru');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PH', 'Philippines');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PN', 'Pitcairn');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PL', 'Poland');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PT', 'Portugal');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PR', 'Puerto Rico');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('QA', 'Qatar');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('RE', 'Reunion');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('RO', 'Romania');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('RU', 'Russian Federation');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('RW', 'Rwanda');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('KN', 'Saint Kitts and Nevis');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LC', 'Saint Lucia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('VC', 'Saint Vincent and the Grenadines');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('WS', 'Samoa');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SM', 'San Marino');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ST', 'Sao Tome and Principe');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SA', 'Saudi Arabia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SN', 'Senegal');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('RS', 'Serbia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SC', 'Seychelles');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SL', 'Sierra Leone');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SG', 'Singapore');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SK', 'Slovakia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SI', 'Slovenia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SB', 'Solomon Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SO', 'Somalia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ZA', 'South Africa');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GS', 'South Georgia South Sandwich Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ES', 'Spain');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('LK', 'Sri Lanka');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SH', 'St. Helena');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('PM', 'St. Pierre and Miquelon');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SD', 'Sudan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SR', 'Suriname');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SJ', 'Svalbarn and Jan Mayen Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SZ', 'Swaziland');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SE', 'Sweden');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('CH', 'Switzerland');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('SY', 'Syrian Arab Republic');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TW', 'Taiwan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TJ', 'Tajikistan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TZ', 'Tanzania, United Republic of');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TH', 'Thailand');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TG', 'Togo');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TK', 'Tokelau');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TO', 'Tonga');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TT', 'Trinidad and Tobago');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TN', 'Tunisia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TR', 'Turkey');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TM', 'Turkmenistan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TC', 'Turks and Caicos Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('TV', 'Tuvalu');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('UG', 'Uganda');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('UA', 'Ukraine');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('AE', 'United Arab Emirates');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('GB', 'United Kingdom');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('UM', 'United States minor outlying islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('UY', 'Uruguay');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('UZ', 'Uzbekistan');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('VU', 'Vanuatu');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('VA', 'Vatican City State');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('VE', 'Venezuela');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('VN', 'Vietnam');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('VG', 'Virgin Islands (British)');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('VI', 'Virgin Islands (U.S.)');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('WF', 'Wallis and Futuna Islands');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('EH', 'Western Sahara');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('YE', 'Yemen');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('YU', 'Yugoslavia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ZR', 'Zaire');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ZM', 'Zambia');
INSERT INTO [Lookup].[Country] (Code, Name) VALUES ('ZW', 'Zimbabwe');

--------------- Insert State List -------------------------

INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AD', 'Canillo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AD', 'Andorra la Vella');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AD', 'Escaldes-Engordany');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AD', 'Sant Julia de Loria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AD', 'Ordino');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AD', 'La Massana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AD', 'Encamp');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AE', 'Dubayy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AE', 'Ash Shariqah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AE', 'Al Fujayrah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AE', '`Ajman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AE', 'Abu Zaby');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AE', 'Umm al Qaywayn');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AE', 'Ra''s al Khaymah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wardak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Sar-e Pul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Samangan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Parwan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Paktika');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Paktiya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Uruzgan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Nimroz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Nangarhar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Logar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Laghman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Kunduz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Kunar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Kapisa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Kandahar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Kabul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Jowzjan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Herat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Helmand');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Ghor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Ghazni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Faryab Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Farah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Bamyan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Balkh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Baghlan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Badghis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Badakhshan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Velayat-e Nurestan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Velayat-e Khowst');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Takhar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Wilayat-e Zabul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Daykundi Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AF', 'Panjshir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AG', 'Parish of Saint Philip');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AG', 'Parish of Saint Peter');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AG', 'Parish of Saint Paul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AG', 'Parish of Saint Mary');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AG', 'Parish of Saint John');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AG', 'Parish of Saint George');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AG', 'Redonda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AG', 'Barbuda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Durresit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Fierit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Lezhes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Shkodres');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Tiranes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Vlores');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Beratit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Dibres');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Elbasanit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Gjirokastres');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Korces');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AL', 'Qarku i Kukesit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Ararati Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Syunik''i Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Vayots'' Dzori Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Yerevan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Aragatsotni Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Armaviri Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Geghark''unik''i Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Kotayk''i Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Lorru Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Shiraki Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AM', 'Tavushi Marz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Malanje Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Luanda Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Cuanza Norte Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Cabinda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Bengo Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Namibe Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Huila Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Huambo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Cunene Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Kwanza Sul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Provincia do Bie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Benguela');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Lunda Sul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Lunda Norte Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Moxico');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Kuando Kubango');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Zaire');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AO', 'Provincia do Uige');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Misiones');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Formosa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Ciudad Autonoma de Buenos Aires');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Entre Rios');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Corrientes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Buenos Aires');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Tucuman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Tierra del Fuego, Antartida e Islas del Atlantico Sur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Santiago del Estero');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Santa Fe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Santa Cruz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de San Luis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de San Juan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Salta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Rio Negro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia del Neuquen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Mendoza');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de La Rioja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de La Pampa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Jujuy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Cordoba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia del Chubut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia del Chaco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AR', 'Provincia de Catamarca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AT', 'Wien');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AT', 'Vorarlberg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AT', 'Oberoesterreich');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AT', 'Niederoesterreich');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AT', 'Salzburg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AT', 'Kaernten');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AT', 'Tirol');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AT', 'Steiermark');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AT', 'Burgenland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AU', 'State of Western Australia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AU', 'State of Tasmania');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AU', 'State of New South Wales');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AU', 'Northern Territory');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AU', 'State of Victoria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AU', 'State of South Australia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AU', 'State of Queensland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AU', 'Australian Capital Territory');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Beylagan Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Zangilan Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Yardymli Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Susa Rayonu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Salyan Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Sabirabad Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Saatly Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Bilasuvar Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Neftchala Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Nakhchivan Autonomous Republic');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Masally District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Lerik Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Lankaran Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Lacin Rayonu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Qubadli Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Imishli Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Fizuli Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Cabrayil Rayonu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Jalilabad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Astara District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Xocali Rayonu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Aghjabadi Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Aghdam Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Shirvan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Lankaran Sahari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Shusha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Tartar Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Xankandi Sahari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Xocavand Rayonu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Zardab Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Zaqatala Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Yevlakh Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Oghuz Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Ujar Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Tovuz Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Shamakhi Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Shaki Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Shamkir Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Kurdamir Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Qabala Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Qusar Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Quba Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Goygol Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Khachmaz Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Kalbacar Rayonu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Qazakh Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Goranboy Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Qakh Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Ismayilli Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Goychay Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Shabran Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Dashkasan Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Balakan Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Barda Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Baku City');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Absheron Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Aghsu Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Aghdash Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Gadabay Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Aghstafa Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Ganja City');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Mingacevir City');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Naftalan City');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Gobustan Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Samukh Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Shaki city');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Siazan Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Sumqayit City');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Khizi Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Yevlakh City');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Hajigabul Rayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('AZ', 'Naxcivan Sahari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BA', 'Brcko');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BA', 'Federation of Bosnia and Herzegovina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BA', 'Republika Srpska');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint Thomas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint Philip');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint Peter');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint Michael');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint Lucy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint Joseph');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint John');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint James');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint George');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Saint Andrew');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BB', 'Christ Church');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BD', 'Rajshahi Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BD', 'Dhaka Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BD', 'Chittagong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BD', 'Khulna Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BD', 'Barisal Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BD', 'Sylhet Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BD', 'Rangpur Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BE', 'Walloon Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BE', 'Flanders');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BE', 'Bruxelles-Capitale');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Boucle du Mouhoun Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Cascades Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Centre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Centre-Est');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Centre-Nord');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Centre-Ouest');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Centre-Sud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Est');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'High-Basins Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Nord');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Plateau-Central');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Sahel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BF', 'Southwest Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Razgrad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Montana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Khaskovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Sofiya-Grad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Vratsa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Varna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Dobrich');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Sofiya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Burgas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Blagoevgrad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Lovech');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Ruse');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Plovdiv');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Pleven');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Pernik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Pazardzhik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Gabrovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Kurdzhali');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Kyustendil');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Shumen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Silistra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Sliven');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Smolyan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Stara Zagora');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Turgovishte');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Veliko Turnovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Vidin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BG', 'Oblast Yambol');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BH', 'Muharraq Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BH', 'Capital Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BH', 'Southern Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BH', 'Central Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BH', 'Northern Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Makamba Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Bururi Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Kirundo Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Rutana Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Province de Mwaro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Bujumbura Mairie Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Bujumbura Rural Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Muramvya Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Gitega Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Ruyigi Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Cankuzo Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Karuzi Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Bubanza Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Cibitoke Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Ngozi Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Kayanza Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BI', 'Muyinga Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Departement de l''Oueme');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Mono');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Borgou Department');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Atlantique Department');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Atakora Department');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Alibori');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Collines Department');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Kouffo Department');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Donga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Littoral');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Plateau Department');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BJ', 'Zou Department');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Warwick Parish');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Southampton Parish');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Smith''s Parish');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Sandys Parish');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Saint George''s Parish');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Saint George');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Pembroke Parish');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Paget Parish');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Hamilton');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Hamilton');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BM', 'Devonshire Parish');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BN', 'Tutong District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BN', 'Temburong District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BN', 'Brunei and Muara District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BN', 'Belait District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BO', 'Departamento de La Paz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BO', 'Departamento de Cochabamba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BO', 'Departamento de Chuquisaca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BO', 'Departamento de Pando');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BO', 'Departamento de Oruro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BO', 'Departamento de Potosi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BO', 'El Beni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BO', 'Departamento de Tarija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BO', 'Departamento de Santa Cruz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Sergipe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Sao Paulo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Acre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Rio Grande do Norte');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Amapa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Alagoas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Rondonia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Piaui');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Pernambuco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Paraiba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Para');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Ceara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Santa Catarina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Rio Grande do Sul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Rio de Janeiro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Parana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Minas Gerais');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Estado de Mato Grosso do Sul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Mato Grosso');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Goias');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Distrito Federal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Espirito Santo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Estado da Bahia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Tocantins');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Roraima');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Maranhao');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BR', 'Amazonas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Black Point District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Central Abaco District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Central Andros District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Central Eleuthera District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Crooked Island and Long Cay District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'East Grand Bahama District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Grand Cay District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Hope Town District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Mangrove Cay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Moore''s Island District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'North Abaco District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'North Andros District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'North Eleuthera District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Rum Cay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'South Abaco District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'South Andros');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'South Eleuthera');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Spanish Wells District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'West Grand Bahama District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'San Salvador District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Ragged Island District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Berry Islands District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'New Providence District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Mayaguana District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Long Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Inagua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Harbour Island District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'City of Freeport District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Exuma District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Cat Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Bimini District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BS', 'Acklins Island District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Bumthang Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Chhukha Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Dagana Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Tsirang Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Sarpang Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Haa Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Lhuentse Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Mongar Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Paro Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Pemagatshel Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Punakha Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Samtse Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Samdrup Jongkhar Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Zhemgang Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Trashigang Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Thimphu Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Trongsa Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Wangdue Phodrang Dzongkhag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Gasa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BT', 'Trashi Yangste');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BW', 'Southern District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BW', 'South East District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BW', 'North East District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BW', 'North West District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BW', 'Kweneng District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BW', 'Kgatleng District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BW', 'Kgalagadi District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BW', 'Ghanzi District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BW', 'Central District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BY', 'Vitebsk Oblast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BY', 'Mogilyov Oblast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BY', 'Minsk Oblast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BY', 'Horad Minsk');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BY', 'Grodno Oblast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BY', 'Gomel Oblast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BY', 'Brest Oblast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BZ', 'Toledo District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BZ', 'Stann Creek District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BZ', 'Orange Walk District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BZ', 'Corozal District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BZ', 'Cayo District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('BZ', 'Belize District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'British Columbia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'New Brunswick');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Prince Edward Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Quebec');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Manitoba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Ontario');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Yukon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Alberta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Northwest Territories');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Nova Scotia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Nunavut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Saskatchewan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CA', 'Newfoundland and Labrador');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Vakaga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Prefecture de la Sangha-Mbaere');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Prefecture de l''Ouham-Pende');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Ouham');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Ombella-Mpoko');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Prefecture de la Nana-Mambere');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Lobaye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Basse-Kotto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Bamingui-Bangoran');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Ouaka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Mbomou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Haut-Mbomou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Haute-Kotto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Prefecture de la Kemo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Mambere-Kadei');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Prefecture de la Nana-Grebizi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CF', 'Commune de Bangui');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Sangha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Pool');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Plateaux');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Likouala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Lekoumou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Region du Kouilou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Commune de Brazzaville');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Cuvette-Ouest');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Pointe-Noire');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Region du Niari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Cuvette');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CG', 'Region de la Bouenza');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Solothurn');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Schwyz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Schaffhausen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton St. Gallen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Obwalden');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Nidwalden');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Neuchatel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Luzern');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Jura');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Zurich');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Zug');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Canton de Vaud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Canton du Valais');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Uri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Ticino');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Thurgau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Graubunden');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Glarus');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Geneve');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Canton de Fribourg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Canton de Berne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Basel-Stadt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Basel-Landschaft');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Appenzell Ausserrhoden');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Appenzell Innerrhoden');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CH', 'Kanton Aargau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Lagunes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Region du Sud-Comoe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Agneby');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Haut-Sassandra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Savanes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Vallee du Bandama');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Moyen-Comoe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'District des Montagnes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Lacs');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Zanzan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Bas-Sassandra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Worodougou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Denguele');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Sud-Bandama');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Fromager');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'N''zi-Comoe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Marahoue');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Moyen-Cavally');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CI', 'Bafing');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Region Metropolitana de Santiago');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Region del Libertador General Bernardo O''Higgins');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Region del Biobio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Atacama');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Region de la Araucania');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Antofagasta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Los Lagos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Coquimbo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Aysen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Region de Valparaiso');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Region de Tarapaca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Maule');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Region de Magallanes y de la Antartica Chilena');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Region de Arica y Parinacota');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CL', 'Region de Los Rios');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'Littoral Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'Adamaoua Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'West Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'North-West Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'North Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'Centre Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'South-West Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'South Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'Far North Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CM', 'East Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Zhejiang Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Jiangxi Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Jiangsu Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Guangdong Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Gansu Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Fujian Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Anhui Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Tibet Autonomous Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Qinghai Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Yunnan Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Tianjin Shi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Ningxia Huizu Zizhiqu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Hunan Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Hubei Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Chongqing Shi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Inner Mongolia Autonomous Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Xinjiang Uygur Zizhiqu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Sichuan Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Henan Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Hebei Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Hainan Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Guizhou Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Guangxi Zhuangzu Zizhiqu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Beijing Shi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Shanxi Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Shanghai Shi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Shandong Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Shaanxi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Liaoning Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Jilin Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CN', 'Heilongjiang Sheng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Sucre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Santander');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Bolivar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Distrito Capital de Bogota');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Atlantico');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Arauca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Antioquia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Amazonas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Providencia y Santa Catalina, Departamento de Archipielago de San Andres');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Risaralda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Quindio Department');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Putumayo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de La Guajira');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Vichada');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Vaupes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Valle del Cauca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Tolima');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Norte de Santander');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Narino');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Meta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Magdalena');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Cundinamarca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Cordoba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Choco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Huila');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Guaviare');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Guainia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Cesar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Cauca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Casanare');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento del Caqueta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Caldas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CO', 'Departamento de Boyaca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CR', 'Provincia de San Jose');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CR', 'Provincia de Puntarenas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CR', 'Provincia de Limon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CR', 'Provincia de Heredia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CR', 'Provincia de Guanacaste');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CR', 'Provincia de Cartago');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CR', 'Provincia de Alajuela');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Villa Clara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Pinar del Rio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Artemisa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia Mayabeque');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Las Tunas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Sancti Spiritus');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Guantanamo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia Granma');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Santiago de Cuba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Matanzas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Municipio Especial Isla de la Juventud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Holguin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'La Habana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Cienfuegos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Ciego de Avila');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CU', 'Provincia de Camaguey');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho do Tarrafal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho de Sao Vicente');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho de Santa Catarina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Sal Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho da Ribeira Grande');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho da Praia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho do Paul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho do Maio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho da Brava');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho da Boa Vista');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho dos Mosteiros');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho de Santa Cruz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho de Sao Domingos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho do Sao Filipe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho de Sao Miguel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho do Porto Novo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho da Ribeira Brava');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho de Santa Catarina do Fogo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho de Sao Salvador do Mundo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho do Tarrafal de Sao Nicolau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Sao Lourenco dos Orgaos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CV', 'Concelho de Ribeira Grande de Santiago');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CY', 'Eparchia Pafou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CY', 'Eparchia Lefkosias');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CY', 'Eparchia Lemesou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CY', 'Larnaca District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CY', 'Eparchia Keryneias');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CY', 'Eparchia Ammochostou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Jihomoravsky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Jihocesky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Kraj Vysocina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Karlovarsky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Kralovehradecky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Liberecky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Olomoucky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Moravskoslezsky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Pardubicky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Plzensky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Stredocesky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Ustecky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Zlinsky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('CZ', 'Hlavni mesto Praha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Schleswig-Holstein');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Rheinland-Pfalz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Thuringia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Saxony-Anhalt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Saxony');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Saarland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Nordrhein-Westfalen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Lower Saxony');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Hessen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Land Berlin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Free and Hanseatic City of Hamburg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Baden-Wuerttemberg Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Mecklenburg-Western Pomerania');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Bremen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Brandenburg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DE', 'Bavaria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DJ', 'Djibouti Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DJ', 'Dikhil');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DJ', 'Ali Sabieh Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DJ', 'Arta Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DJ', 'Tadjourah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DJ', 'Obock');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DK', 'Region Hovedstaden');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DK', 'Region Midtjylland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DK', 'North Denmark Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DK', 'Region Sjaelland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DK', 'Region Syddanmark');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint Peter');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint Paul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint Patrick');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint Mark');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint Luke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint Joseph');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint John');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint George');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint David');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DM', 'Saint Andrew');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Valverde');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de La Vega');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de La Romana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia Duarte');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Dajabon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Peravia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Pedernales');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Distrito Nacional');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Monte Plata');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Monte Cristi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Monsenor Nouel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de La Altagracia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Independencia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Hato Mayor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia Maria Trinidad Sanchez');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia Espaillat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de El Seibo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Elias Pina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Santiago Rodriguez');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Santiago');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de San Pedro de Macoris');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de San Juan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de San Cristobal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia Sanchez Ramirez');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Samana Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Hermanas Mirabal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Puerto Plata');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Barahona');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Baoruco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Azua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de San Jose de Ocoa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DO', 'Provincia de Santo Domingo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Sidi Bel Abbes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Setif');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Saida');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Mascara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Laghouat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Guelma');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Ghardaia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'El Tarf');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'El Oued');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Bejaia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Bechar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Batna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Tlemcen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Tizi Ouzou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Tissemsilt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Tipaza');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Tindouf');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Relizane');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Oum el Bouaghi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Khenchela');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Jijel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Djelfa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Constantine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Chlef');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Ain Defla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Adrar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Souk Ahras');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Skikda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Mila');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Medea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'El Bayadh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Annaba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya d'' Alger');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Ain Temouchent');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Tiaret');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Tebessa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Tamanrasset');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Ouargla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Oran');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Naama');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de M''Sila');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Mostaganem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Illizi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Boumerdes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Bouira');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Bordj Bou Arreridj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Blida');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('DZ', 'Wilaya de Biskra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Zamora-Chinchipe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia del Tungurahua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Cotopaxi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia del Chimborazo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia del Carchi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia del Canar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Bolivar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Manabi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Los Rios');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Loja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Imbabura');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia del Guayas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Galapagos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Esmeraldas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de El Oro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Pichincha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia del Pastaza');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Napo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Morona-Santiago');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia del Azuay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Sucumbios');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Francisco de Orellana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Santo Domingo de los Tsachilas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EC', 'Provincia de Santa Elena');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Laane-Virumaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Laeaenemaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Jogevamaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Jarvamaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Ida-Virumaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Hiiumaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Harjumaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Vorumaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Viljandimaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Valgamaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Tartumaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Saaremaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Raplamaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Polvamaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EE', 'Parnumaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat Qina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Uqsur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Kafr ash Shaykh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat Asyut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat Aswan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'As Suways');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat ash Sharqiyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Wadi al Jadid');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Qalyubiyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Qahirah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Minya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Minufiyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat Suhaj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat Matruh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat Dumyat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat Bur Sa`id');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat Bani Suwayf');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat Shamal Sina''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'South Sinai Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Jizah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Ismailia Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Iskandariyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Gharbiyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat al Fayyum');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Beheira Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Red Sea Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EG', 'Muhafazat ad Daqahliyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('EH', 'Oued Ed-Dahab-Lagouira');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ER', 'Anseba Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ER', 'Debub Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ER', 'Southern Red Sea Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ER', 'Gash-Barka Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ER', 'Maekel Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ER', 'Northern Red Sea Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Comunitat Autonoma de les Illes Balears');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Comunidad de Madrid');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Region de Murcia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Ceuta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Principality of Asturias');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Navarra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'La Rioja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Cantabria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Aragon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Castilla y Leon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Catalunya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Galicia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Euskal Autonomia Erkidegoa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Melilla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Andalucia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Canary Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Castilla-La Mancha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Extremadura');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ES', 'Comunitat Valenciana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Adis Abeba Astedader');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Afar Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Amhara Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Benishangul-Gumuz Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Dire Dawa Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Gambela Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Harari Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Oromiya Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Somali Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Tigray Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ET', 'Southern Nations, Nationalities, and People''s Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Lappi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Kainuu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Pohjois-Pohjanmaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Keski-Pohjanmaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Pohjanmaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Etela-Pohjanmaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Keski-Suomi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Pohjois-Karjala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Pohjois-Savo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Southern Savonia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Etelae-Karjala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Kymenlaakso');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Pirkanmaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Haeme');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Varsinais-Suomi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Uusimaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Paijanne-Tavastland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FI', 'Satakunta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FJ', 'Northern Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FJ', 'Eastern Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FJ', 'Rotuma');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FJ', 'Kadavu Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FJ', 'Western Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FJ', 'Central Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FM', 'State of Yap');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FM', 'State of Pohnpei');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FM', 'State of Kosrae');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FM', 'State of Chuuk');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FO', 'Vaga Sysla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FO', 'Suduroyar sysla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FO', 'Streymoyar Sysla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FO', 'Sandoyar Sysla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FO', 'Nordoyar sysla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FO', 'Eysturoyar sysla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Picardie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Pays de la Loire');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Bourgogne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Provence-Alpes-Cote d''Azur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Poitou-Charentes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Midi-Pyrenees');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Franche-Comte');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Corse');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Rhone-Alpes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Limousin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Languedoc-Roussillon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Champagne-Ardenne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Centre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Basse-Normandie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Auvergne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Nord-Pas-de-Calais');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Lorraine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Ile-de-France');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Haute-Normandie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Bretagne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Aquitaine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('FR', 'Alsace');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GA', 'Province du Woleu-Ntem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GA', 'Province du Haut-Ogooue');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GA', 'Estuaire');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GA', 'Province de l''Ogooue-Maritime');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GA', 'Province de l''Ogooue-Lolo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GA', 'Province de l''Ogooue-Ivindo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GA', 'Province de la Nyanga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GA', 'Province de la Ngounie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GA', 'Province du Moyen-Ogooue');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GB', 'Scotland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GB', 'Wales');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GB', 'Northern Ireland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GB', 'England');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GD', 'Saint Patrick');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GD', 'Saint Mark');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GD', 'Saint John');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GD', 'Saint George');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GD', 'Saint David');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GD', 'Saint Andrew');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GD', 'Carriacou and Petite Martinique');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'K''alak''i T''bilisi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Abkhazia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Ajaria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Kvemo Kartli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Kakheti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Guria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Imereti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Shida Kartli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Mtskheta-Mtianeti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Racha-Lechkhumi and Kvemo Svaneti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Samegrelo-Zemo Svanetis Mkhare');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GE', 'Samtskhe-Javakheti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GF', 'Guyane');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Western Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Volta Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Upper West Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Upper East Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Central Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Brong-Ahafo Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Greater Accra Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Eastern Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Ashanti Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GH', 'Northern Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GL', 'Qaasuitsup');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GL', 'Kujalleq');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GL', 'Qeqqata');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GL', 'Sermersooq');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GM', 'Western Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GM', 'Upper River Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GM', 'North Bank Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GM', 'Central River Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GM', 'Lower River Division');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GM', 'City of Banjul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GN', 'Conakry Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GN', 'Boke Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GN', 'Faranah Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GN', 'Kankan Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GN', 'Kindia Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GN', 'Labe Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GN', 'Mamou Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GN', 'Nzerekore Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GP', 'Guadeloupe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GQ', 'Provincia de Annobon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GQ', 'Provincia de Bioko Norte');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GQ', 'Provincia de Bioko Sur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GQ', 'Provincia de Centro Sur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GQ', 'Provincia de Kie-Ntem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GQ', 'Provincia de Litoral');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GQ', 'Provincia de Wele-Nzas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'Mount Athos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'Attica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'Central Greece');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'Central Macedonia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'Crete');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'East Macedonia and Thrace');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'Epirus');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'Ionian Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'North Aegean');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'Peloponnese');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'South Aegean');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'Thessaly');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'West Greece');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GR', 'West Macedonia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Zacapa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Jutiapa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Jalapa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Izabal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Huehuetenango');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Guatemala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Escuintla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de El Progreso');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Totonicapan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Suchitepequez');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Solola');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Santa Rosa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de San Marcos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Chiquimula');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Chimaltenango');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Sacatepequez');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Retalhuleu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento del Quiche');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Quetzaltenango');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento del Peten');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Baja Verapaz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GT', 'Departamento de Alta Verapaz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Piti Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Santa Rita Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Sinajana Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Talofofo Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Tamuning-Tumon-Harmon Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Umatac Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Yigo Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Yona Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Merizo Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Mangilao Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Agana Heights Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Chalan Pago-Ordot Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Asan-Maina Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Agat Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Dededo Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Barrigada Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Hagatna Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Inarajan Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GU', 'Mongmong-Toto-Maite Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GW', 'Bafata');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GW', 'Cacheu Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GW', 'Bolama');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GW', 'Bissau Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GW', 'Biombo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GW', 'Quinara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GW', 'Oio Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GW', 'Gabu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GW', 'Tombali');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'Mahaica-Berbice Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'Essequibo Islands-West Demerara Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'East Berbice-Corentyne Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'Demerara-Mahaica Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'Cuyuni-Mazaruni Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'Barima-Waini Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'Upper Takutu-Upper Essequibo Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'Upper Demerara-Berbice Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'Potaro-Siparuni Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('GY', 'Pomeroon-Supenaam Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Tuen Mun');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'North');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Sha Tin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Yuen Long District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Tsuen Wan District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Tai Po District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Sai Kung District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Islands District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Central and Western District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Wan Chai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Eastern');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Southern');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Yau Tsim Mong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Sham Shui Po');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Kowloon City');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Wong Tai Sin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Kwon Tong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HK', 'Kwai Tsing');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de La Paz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Yoro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Valle');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Santa Barbara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Islas de la Bahia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Intibuca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Gracias a Dios');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Francisco Morazan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de El Paraiso');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Ocotepeque');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Lempira');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Copan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Comayagua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Colon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Choluteca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Atlantida');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Olancho');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HN', 'Departamento de Cortes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Bjelovarsko-Bilogorska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Brodsko-Posavska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Dubrovacko-Neretvanska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Istarska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Karlovacka Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Koprivnicko-Krizevacka Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Krapinsko-Zagorska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Licko-Senjska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Medimurska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Osjecko-Baranjska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Pozesko-Slavonska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Primorsko-Goranska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Sibensko-Kninska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Sisacko-Moslavacka Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Splitsko-Dalmatinska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Varazdinska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Vukovarsko-Srijemska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Zadarska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Zagreb County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Grad Zagreb');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HR', 'Viroviticko-Podravska Zupanija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Sud-Est');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Sud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Grandans');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Departement de l''Ouest');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Centre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Nord-Ouest');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Departement du Nord-Est');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Nord');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Departement de l''Artibonite');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HT', 'Departement de Nippes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Csongrad megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Borsod-Abauj Zemplen county');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Bekes County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Komarom-Esztergom');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Jasz-Nagykun-Szolnok');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Heves megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Hajdu-Bihar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Pest megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Nograd megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Baranya county');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Bacs-Kiskun county');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Somogy megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Fejer megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Budapest fovaros');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Szabolcs-Szatmar-Bereg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Zala megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Veszprem megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Vas megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Tolna megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('HU', 'Gyor-Moson-Sopron megye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Nanggroe Aceh Darussalam Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Daerah Istimewa Yogyakarta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Riau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Maluku');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Maluku Utara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Lampung');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Propinsi Bengkulu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Banten');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Gorontalo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Kepulauan Bangka Belitung');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Papua Barat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Sulawesi Barat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Kepulauan Riau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Sumatera Utara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Sumatera Selatan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Sumatera Barat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Sulawesi Utara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Sulawesi Tenggara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Sulawesi Tengah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Sulawesi Selatan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Nusa Tenggara Timur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'West Nusa Tenggara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Kalimantan Timur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Kalimantan Tengah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Kalimantan Selatan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Kalimantan Barat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Jawa Timur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Jawa Tengah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Jawa Barat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Jambi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Daerah Khusus Ibukota Jakarta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Papua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'Provinsi Bali');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ID', 'North Kalimantan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IE', 'Connaught');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IE', 'Leinster');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IE', 'Munster');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IE', 'Ulster');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IL', 'Jerusalem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IL', 'Tel Aviv District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IL', 'Haifa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IL', 'Northern District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IL', 'Central District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IL', 'Southern District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Rajasthan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Punjab');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'Union Territory of Puducherry');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Karnataka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Jammu and Kashmir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Assam');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Arunachal Pradesh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Chhattisgarh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Jharkhand');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Uttarakhand');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Uttar Pradesh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Tripura');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'Telangana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Tamil Nadu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Mizoram');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Meghalaya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Manipur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Maharashtra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'Madhya Pradesh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'National Capital Territory of Delhi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'Union Territory of Dadra and Nagar Haveli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Sikkim');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'Union Territory of Lakshadweep');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Kerala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'Union Territory of Chandigarh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Bihar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of West Bengal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Odisha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Nagaland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Himachal Pradesh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Haryana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Gujarat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'Union Territory of Daman and Diu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'Goa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'State of Andhra Pradesh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IN', 'Union Territory of Andaman and Nicobar Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat al Basrah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Wasit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Diyala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Dhi Qar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Dihok');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Ninawa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat al Qadisiyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat al Muthanna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat al Anbar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Salah ad Din');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Baghdad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Babil');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Kirkuk');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat as Sulaymaniyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'An Najaf');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Maysan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Karbala''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IQ', 'Muhafazat Arbil');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Yazd');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Semnan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Mazandaran');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Markazi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Fars');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Khorasan-e Jonubi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Khorasan-e Razavi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Khorasan-e Shomali');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Alborz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Kordestan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Kohgiluyeh va Bowyer Ahmad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Khuzestan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Hamadan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Sistan va Baluchestan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Tehran');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Zanjan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Kermanshah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Kerman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Gilan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Chahar Mahal va Bakhtiari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Bushehr');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Ardabil');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Esfahan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Golestan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Qazvin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Qom');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Lorestan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Ilam');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Hormozgan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Azarbayjan-e Sharqi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IR', 'Ostan-e Azarbayjan-e Gharbi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IS', 'Hofudborgarsvadi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IS', 'Sudurnes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IS', 'Vesturland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IS', 'Vestfirdir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IS', 'Nordurland Vestra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IS', 'Nordurland Eystra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IS', 'Austurland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IS', 'Sudurland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Trentino-Alto Adige');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Toscana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Marche');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Lombardia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Liguria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Lazio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Basilicata');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Friuli Venezia Giulia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Abruzzo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Sicilia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Sardegna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Regione Calabria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Regione Veneto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Regione Autonoma Valle d''Aosta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Umbria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Molise');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Campania');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Puglia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Piemonte');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('IT', 'Emilia-Romagna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Westmoreland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Trelawny');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Saint Thomas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Saint Mary');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Saint James');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Saint Elizabeth');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Saint Catherine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Saint Ann');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Saint Andrew');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Portland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Manchester');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Kingston');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Hanover');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JM', 'Parish of Clarendon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Muhafazat az Zarqa''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Muhafazat at Tafilah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Muhafazat `Amman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Al Mafraq');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Al Karak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Muhafazat al Balqa''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Ajloun');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Jerash');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Muhafazat al `Aqabah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Muhafazat Madaba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Irbid');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JO', 'Muhafazat Ma`an');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Toyama-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Tottori-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Tokyo-to');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Tokushima-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Tochigi-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Mie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Kyoto-fu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Kumamoto-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Aichi-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Yamanashi-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Yamaguchi-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Wakayama-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Niigata');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Nara-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Nagasaki-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Nagano');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Miyazaki-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Gunma-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Gifu-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Fukuoka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Fukui-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Ehime-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Shizuoka-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Shimane-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Shiga-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Saitama-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Saga-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Kochi-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Kanagawa-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Yamagata');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Hokkaido');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Aomori-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Osaka-fu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Okinawa-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Okayama');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Oita');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Kagoshima-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Kagawa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Ishikawa-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Hyogo-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Hiroshima-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Miyagi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Iwate-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Ibaraki-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Fukushima');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Chiba-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('JP', 'Akita-ken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kisii District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kirinyaga District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kilifi District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kiambu District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kericho District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Nyandarua District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Vihiga District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Lamu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Machakos District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Makueni District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Marakwet District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Taita Taveta District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kajiado District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Nyeri District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Homa Bay District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Bomet District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Migori District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Keiyo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Nakuru District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Narok District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Nyamira District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Nandi South District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Tharaka District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Tana River District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Siaya District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Samburu District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Laikipia District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kwale District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kitui District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kisumu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Embu District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Busia District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Bungoma District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Baringo District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Nairobi Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Murang''a District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Mombasa District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Kakamega District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'West Pokot District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Wajir District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Uasin Gishu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Turkana District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Trans Nzoia District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Meru Central District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Marsabit District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Mandera District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Isiolo District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KE', 'Garissa District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KG', 'Jalal-Abad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KG', 'Chuyskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KG', 'Osh Oblasty');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KG', 'Batken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KG', 'Talas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KG', 'Naryn');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KG', 'Issyk-Kul''skaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KG', 'Gorod Bishkek');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Pursat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Battambang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Takeo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Svay Rieng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Stung Treng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Otar Meanchey');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Siem Reap');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Ratanakiri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Prey Veng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Preah Vihear');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Phnom Penh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Pailin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Mondolkiri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Kratie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Kep');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Koh Kong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Kandal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Kampot');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Kampong Thom');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Kampong Speu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Kampong Chhnang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Kampong Cham');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Sihanoukville');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KH', 'Banteay Meanchey');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KI', 'Gilbert Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KI', 'Line Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KI', 'Phoenix Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KM', 'Mwali');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KM', 'Grande Comore');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KM', 'Ndzuwani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Trinity Palmetto Point');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint Thomas Middle Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint Thomas Lowland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint Peter Basseterre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint Paul Charlestown');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint Paul Capesterre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint Mary Cayon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint John Figtree');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint John Capesterre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint James Windward');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint George Gingerland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint George Basseterre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Saint Anne Sandy Point');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KN', 'Christ Church Nichola Town');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'Kangwon-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'Pyongyang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'P''yongan-namdo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'P''yongan-bukto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'Chagang-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'Rason');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'Hwanghae-namdo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'Hwanghae-bukto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'Hamnam');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'Yanggang-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KP', 'Hambuk');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Daejeon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Daegu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Busan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Gyeongsangbuk-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Gyeonggi-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Gwangju');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Gangwon-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Chungcheongnam-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Chungcheongbuk-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Jeollanam-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Jeollabuk-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Jeju-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Ulsan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Seoul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Incheon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Gyeongsangnam-do');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KR', 'Sejong-si');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KW', 'Muhafazat Hawalli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KW', 'Al Asimah Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KW', 'Muhafazat al Jahra''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KW', 'Muhafazat al Farwaniyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KW', 'Muhafazat al Ahmadi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KW', 'Muhafazat Mubarak al Kabir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Batys Qazaqstan Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Aqmola Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Severo-Kazakhstanskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Almaty Qalasy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Aktyubinskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Qaraghandy Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Mangistauskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Atyrau Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Pavlodar Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Qyzylorda Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Qostanay Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Shyghys Qazaqstan Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Zhambyl Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Yuzhno-Kazakhstanskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Almaty Oblysy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Bayqongyr Qalasy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('KZ', 'Astana Qalasy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Xiangkhouang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Xaignabouli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Vientiane Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Luang Prabang Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Louangnamtha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Khammouan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Houaphan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Champasak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Attapu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Khoueng Xekong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Khoueng Bokeo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Bolikhamxai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Vientiane Prefecture');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Khoueng Savannakhet');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Salavan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Khoueng Phongsali');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LA', 'Khoueng Oudomxai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LB', 'Beyrouth');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LB', 'Mohafazat Liban-Sud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LB', 'Mohafazat Beqaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LB', 'Mohafazat Mont-Liban');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LB', 'Mohafazat Liban-Nord');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LB', 'Mohafazat Nabatiye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LB', 'Mohafazat Aakkar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LB', 'Mohafazat Baalbek-Hermel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Vieux-Fort');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Soufriere');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Quarter of Praslin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Micoud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Laborie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Gros-Islet');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Dennery');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Quarter of Dauphin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Choiseul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Castries');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LC', 'Anse-la-Raye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Vaduz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Triesenberg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Triesen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Schellenberg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Schaan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Ruggell');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Planken');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Mauren');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Gemeinde Gamprin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Eschen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LI', 'Balzers');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LK', 'Central Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LK', 'Province of Uva');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LK', 'Western Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LK', 'North Western Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LK', 'North Central Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LK', 'Southern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LK', 'Province of Sabaragamuwa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LK', 'Northern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LK', 'Eastern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Grand Gedeh County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Grand Cape Mount County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Grand Bassa County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Sinoe County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Nimba County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Montserrado County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Maryland County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Lofa County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Bong County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Bomi County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Grand Kru County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Margibi County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'River Cess County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'Gbarpolu County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LR', 'River Gee County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Thaba-Tseka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Quthing');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Qacha''s Nek');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Mokhotlong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Mohale''s Hoek District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Maseru');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Mafeteng District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Leribe District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Butha-Buthe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LS', 'Berea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Alytaus Apskritis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Kauno Apskritis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Klaipedos Apskritis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Marijampoles Apskritis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Panevezys');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Siauliu Apskritis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Taurages Apskritis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Telsiu Apskritis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Utenos Apskritis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LT', 'Vilniaus Apskritis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LU', 'District de Luxembourg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LU', 'District de Grevenmacher');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LU', 'District de Diekirch');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ventspils Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ventspils');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Valmiera District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Valka Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Tukuma Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Talsi Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Saldus Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Riga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Rezeknes Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Rezekne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Preili Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ogres novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Madona Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ludzas Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Limbazu Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Liepaja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Kuldigas Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Kraslavas Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Jurmala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Jelgavas Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Jelgava');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Jekabpils Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Gulbenes Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Dobeles Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Daugavpils municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Daugavpils');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Cesu Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Bauskas Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Balvu Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Aluksnes Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Aizkraukles Rajons');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Dundagas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Alsungas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Pavilostas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Nicas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Rucavas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Grobinas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Durbes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Aizputes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Priekules Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Vainodes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Skrundas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Brocenu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Rojas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Kandavas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Auces Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Jaunpils Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Engures Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Tervetes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ozolnieku Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Rundales Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Babites Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Marupes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Olaines Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Iecavas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Kekavas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Salaspils Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Baldones Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Stopinu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Carnikavas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Adazu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Garkalne Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Vecumnieku Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Keguma Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Lielvardes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Skriveru Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Jaunjelgavas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Neretas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Viesites Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Salas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Jekabpils');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Aknistes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ilukstes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Varkavas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Livanu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Varaklanu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Vilanu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Riebinu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Aglonas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ciblas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Zilupes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Vilakas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Baltinavas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Dagdas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Karsavas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Rugaju Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Cesvaines Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Lubanas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Krustpils Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Plavinu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Kokneses Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ikskiles Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ropazu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Incukalna Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Krimuldas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Siguldas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Ligatnes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Malpils Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Sejas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Saulkrastu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Salacgrivas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Alojas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Nauksenu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Rujienas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Mazsalacas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Burtnieku Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Pargaujas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Kocenu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Amatas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Priekuli Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Raunas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Strencu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Beverinas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Smiltenes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Jaunpiebalgas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Erglu Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Vecpiebalgas Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Apes Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LV', 'Mersraga Novads');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Darnah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat Banghazi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Al Marj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Al Kufrah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat al Jabal al Akhdar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Tripoli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Surt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat Sabha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat Nalut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Murzuq');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat Misratah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat Ghat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat az Zawiyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat Wadi ash Shati''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Al Jufrah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat an Nuqat al Khams');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat al Butnan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat al Jabal al Gharbi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat al Jafarah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Al Marqab');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat al Wahat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('LY', 'Sha`biyat Wadi al Hayat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Region de Rabat-Sale-Zemmour-Zaer');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Region de Meknes-Tafilalet');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Marrakech-Tensift-Al Haouz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Region de Fes-Boulemane');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Region du Grand Casablanca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Chaouia-Ouardigha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Doukkala-Abda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Gharb-Chrarda-Beni Hssen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Guelmim-Es Semara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Oriental Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Region de Souss-Massa-Draa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Tadla-Azilal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Region de Tanger-Tetouan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Taza-Al Hoceima-Taounate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Laayoune-Boujdour-Sakia El Hamra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MA', 'Oued ed Dahab-Lagouira');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MC', 'Commune de Monaco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Edinet');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Ungheni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Telenesti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Taraclia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Stefan Voda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Straseni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Soroca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Riscani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Rezina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Orhei');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Ocnita');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Anenii Noi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Nisporeni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Leova');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Singerei');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Criuleni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Laloveni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Municipiul Chisinau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Causeni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Cantemir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Calarasi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Cahul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Glodeni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Floresti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Falesti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Dubasari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Raionul Drochia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Donduseni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Cimislia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Briceni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Basarabeasca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Hincesti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Soldanesti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Unitatea Teritoriala din Stinga Nistrului');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Gagauzia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Municipiul Bender');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MD', 'Municipiul Balti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Opstina Rozaje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Opstina Zabljak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Ulcinj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Tivat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Podgorica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Opstina Savnik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Opstina Pluzine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Pljevlja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Opstina Plav');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Opstina Niksic');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Mojkovac');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Kotor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Opstina Kolasin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Berane');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Herceg Novi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Danilovgrad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Cetinje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Budva');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Bijelo Polje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Bar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ME', 'Andrijevica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Diana Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Sava Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Sofia Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Analanjirofo Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Boeny Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Betsiboka Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Alaotra Mangoro Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Melaky Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Bongolava Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Vakinankaratra Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Itasy Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Analamanga Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Atsinanana Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Menabe Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Amoron''i Mania Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Haute Matsiatra Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Vatovavy Fitovinany Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Ihorombe Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Atsimo-Atsinanana Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Anosy Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Androy Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MG', 'Atsimo-Andrefana Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Ailinginae Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Ailinglaplap Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Ailuk Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Arno Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Aur Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Bikar Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Bikini Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Ebon Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Enewetak Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Erikub Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Jaluit Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Kwajalein Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Lae Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Likiep Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Majuro Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Maloelap Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Mili Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Namdrik Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Namu Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Rongelap Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Rongrik Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Taka Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Bokak Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Ujae Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Ujelang Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Utrik Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Wotho Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Wotje Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Jabat Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Jemo Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Kili Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Lib Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MH', 'Mejit Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Valandovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Pehcevo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Novo Selo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Bosilovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Vasilevo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Dojran');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Bogdanci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Konce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Makedonska Kamenica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Zrnovci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Karbinci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Demir Kapija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Rosoman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Gradsko');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Lozovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Cesinovo-Oblesevo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Novaci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Berovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Bitola');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Mogila');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Aracinovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Bogovinje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Petrovec');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Brvenica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Cair');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Caska');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Centar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Centar Zupa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Cucer-Sandevo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Debar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Delcevo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Demir Hisar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Dolneni');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Gjorce Petrov');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Drugovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Gazi Baba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Gevgelija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Gostivar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Ilinden');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Jegunovce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Karpos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Kavadarci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Kicevo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Kisela Voda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Kocani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Kriva Palanka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Krivogastani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Krusevo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Kumanovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Lipkovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Makedonski Brod');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Negotino');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Ohrid');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Oslomej');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Plasnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Prilep');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Probistip');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Radovis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Rankovce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Mavrovo i Rostusa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Saraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Sopiste');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Staro Nagoricane');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Stip');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Struga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Strumica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Studenicani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Suto Orizari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Sveti Nikole');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Tearce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Tetovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Veles');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Vevcani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Vinica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Vranestica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Vrapciste');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Zajas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Zelenikovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Opstina Zelino');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Aerodrom');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Butel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Debarca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Resen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MK', 'Kratovo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ML', 'Kayes Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ML', 'Gao Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ML', 'Sikasso Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ML', 'Segou Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ML', 'Bamako Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ML', 'Mopti Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ML', 'Koulikoro Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ML', 'Kidal Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ML', 'Tombouctou Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Yangon Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Rakhine State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Bago Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Kayah State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Kayin State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Taninthayi Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Mandalay Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Magway Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Kachin State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Ayeyawady Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Shan State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Sagaing Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Mon State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MM', 'Chin State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Ulaanbaatar Hot');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Tov Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Suhbaatar Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Selenge Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Ovorhangay Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'OEmnoegovi Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Dundgovi Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Dornogovi Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Dornod Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Bulgan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Arhangay Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Hovsgol Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Hentiy Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Uvs Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Hovd');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Govi-Altay Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Dzavhan Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Bayan-Olgiy Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Bayanhongor Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Darhan-Uul Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Govi-Sumber');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MN', 'Orhon Aymag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MO', 'Concelho de Macau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MO', 'Concelho das Ilhas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MP', 'Rota Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MP', 'Saipan Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MP', 'Tinian Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MP', 'Northern Islands Municipality');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MQ', 'Martinique');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Adrar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Inchiri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Hodh el Gharbi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Hodh ech Chargui');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Guidimaka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Gorgol');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Dakhlet Nouadhibou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Brakna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Assaba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Wilaya du Trarza');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Tiris Zemmour');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'Tagant');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MR', 'District de Nouakchott');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MS', 'Parish of Saint Peter');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MS', 'Parish of Saint Georges');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MS', 'Parish of Saint Anthony');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Attard');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Balzan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Birgu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Birkirkara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Birzebbuga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Bormla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Dingli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Fgura');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Furjana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Fontana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Ghajnsielem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'L-Gharb');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Hal Gharghur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'L-Ghasri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Hal Ghaxaq');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Gudja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Gzira');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Hamrun');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'L-Iklin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'L-Imdina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'L-Imgarr');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'L-Imqabba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'L-Imsida');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'L-Imtarfa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'L-Isla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Kalkara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Ta'' Kercem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Kirkop');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Lija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Luqa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Marsa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Marsaskala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Marsaxlokk');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Mellieha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Mosta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Munxar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'In-Nadur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'In-Naxxar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Paola');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Pembroke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Tal-Pieta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Qala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Qormi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Qrendi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Ir-Rabat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Safi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Saint John');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Saint Julian''s');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Saint Lawrence');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Saint Lucia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Saint Paul''s Bay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Saint Venera');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Sannat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Is-Siggiewi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Tas-Sliema');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Is-Swieqi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Tarxien');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Ta'' Xbiex');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Ix-Xaghra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Ix-Xewkija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Ix-Xghajra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Haz-Zabbar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Haz-Zebbug');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Iz-Zebbug');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Iz-Zejtun');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Iz-Zurrieq');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MT', 'Il-Belt Valletta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Agalega Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Savanne District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Riviere du Rempart District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Port Louis District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Plaines Wilhems District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Pamplemousses District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Moka District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Grand Port District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Flacq District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Black River District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Cargados Carajos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MU', 'Rodrigues');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Vaavu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Thaa Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Shaviyani Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Seenu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Raa Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Noonu Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Gnaviyani Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Meemu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Lhaviyani Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Laamu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Kaafu Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Haa Dhaalu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Haa Alifu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Gaafu Dhaalu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Gaafu Alifu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Faafu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Dhaalu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Baa Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Alifu Atholhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Maale');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Dhekunu Sarahahdhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Mathi Dhekunu Sarahahdhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Mathi Uthuru Sarahahdhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Medhu Sarahahdhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Medhu Dhekunu Sarahahdhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Medhu Uthuru Sarahahdhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MV', 'Uthuru Sarahahdhu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MW', 'Central Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MW', 'Southern Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MW', 'Northern Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Yucatan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Veracruz-Llave');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Tlaxcala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Oaxaca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Nuevo Leon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Morelos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Mexico');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Hidalgo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Guerrero');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Distrito Federal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Chiapas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Campeche');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Sonora');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Sinaloa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de San Luis Potosi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Nayarit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Durango');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Chihuahua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Aguascalientes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Tamaulipas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Tabasco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Quintana Roo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Queretaro de Arteaga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Puebla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Zacatecas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Michoacan de Ocampo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Jalisco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Guanajuato');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Colima');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Coahuila de Zaragoza');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Baja California Sur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MX', 'Estado de Baja California');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Melaka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Terengganu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Selangor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Sarawak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Sabah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Perlis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Perak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Pahang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Negeri Sembilan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Kelantan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Kuala Lumpur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Pulau Pinang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Kedah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Johor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Labuan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MY', 'Putrajaya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Provincia de Zambezia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Nampula');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Cabo Delgado Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Cidade de Maputo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Niassa Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Maputo Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Manica Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Tete');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Sofala Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Inhambane Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('MZ', 'Gaza Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Khomas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Erongo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Hardap');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Karas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Kunene');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Ohangwena');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Omaheke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Omusati');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Oshana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Oshikoto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Otjozondjupa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Kavango East Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Kavango West Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NA', 'Zambezi Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NC', 'Province Sud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NC', 'Province Nord');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NC', 'Province des iles Loyaute');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NE', 'Zinder');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NE', 'Dosso Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NE', 'Diffa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NE', 'Agadez');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NE', 'Tillaberi Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NE', 'Niamey');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NE', 'Maradi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NE', 'Tahoua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Rivers State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Plateau State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Oyo State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Ondo State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Katsina State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Kano State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Kaduna State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Cross River State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Borno State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Anambra State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Akwa Ibom State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Ogun State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Niger State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Imo State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Benue State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Bauchi State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Sokoto State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Lagos State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Kwara State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Federal Capital Territory');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Abia State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Delta State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Adamawa State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Edo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Enugu State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Jigawa State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Bayelsa State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Ebonyi State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Ekiti State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Gombe State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Nasarawa State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Zamfara State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Kebbi State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Kogi State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Osun State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Taraba State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NG', 'Yobe State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'North Atlantic Autonomous Region (RAAN)');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Region Autonoma Atlantico Sur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Rivas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Rio San Juan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Nueva Segovia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Matagalpa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Masaya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Managua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Madriz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Leon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Jinotega');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Granada');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Esteli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Chontales');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Chinandega');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Carazo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NI', 'Departamento de Boaco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Noord-Holland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Noord-Brabant');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Limburg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Flevoland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Utrecht');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Groningen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Gelderland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Friesland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Overijssel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Drenthe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Zuid-Holland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NL', 'Provincie Zeeland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Finnmark Fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Telemark fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Ostfold fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Oslo County');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Oppland fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Nord-Trondelag Fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Nordland Fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Hordaland Fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Vestfold fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Vest-Agder Fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Sor-Trondelag Fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Sogn og Fjordane Fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'More og Romsdal fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Hedmark fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Aust-Agder fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Akershus fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Troms Fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Rogaland Fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NO', 'Buskerud fylke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NP', 'Sudur Pashchimanchal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NP', 'Madhya Pashchimanchal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NP', 'Madhyamanchal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NP', 'Purwanchal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NP', 'Pashchimanchal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Yaren');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Uaboe District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Nibok District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Meneng District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Ijuw District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Ewa District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Denigomodu District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Buada District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Boe District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Baiti District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Anibare District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Anetan District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Anabar District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NR', 'Aiwo District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Northland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Marlborough');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Tasman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Taranaki');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Southland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Bay of Plenty');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Gisborne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Canterbury');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Wellington');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Manawatu-Wanganui');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Waikato');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Hawke''s Bay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Auckland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Chatham Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Nelson');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'Otago');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('NZ', 'West Coast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Muhafazat ad Dakhiliyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Muhafazat Janub al Batinah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Muhafazat al Wusta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Ash Sharqiyah South');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Az Zahirah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Muhafazat Masqat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Musandam');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Muhafazat Zufar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Muhafazat al Buraymi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Muhafazat Shamal ash Sharqiyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('OM', 'Muhafazat Shamal al Batinah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Provincia de Panama');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Provincia del Darien');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Provincia de Colon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Provincia de Cocle');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Provincia de Chiriqui');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Embera-Wounaan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Ngoebe-Bugle');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Provincia de Veraguas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Guna Yala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Provincia de Los Santos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Provincia de Herrera');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PA', 'Provincia de Bocas del Toro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Region de San Martin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Piura');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Region de Huanuco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Puno');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Departamento de Moquegua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Madre de Dios');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Ica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Huancavelica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Ayacucho');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Arequipa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Apurimac');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Ucayali');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Tumbes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Loreto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Lambayeque');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'La Libertad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Cajamarca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Ancash');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Amazonas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Tacna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Pasco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Provincia de Lima');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Lima');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Junin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Cusco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PE', 'Callao');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PF', 'Iles Tuamotu-Gambier');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PF', 'Iles Sous-le-Vent');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PF', 'Iles du Vent');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PF', 'Iles Australes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PF', 'Iles Marquises');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'West New Britain Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Western Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Western Highlands Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Bougainville');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Northern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'New Ireland Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Enga Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'East Sepik Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'East New Britain Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Eastern Highlands Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Chimbu Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Milne Bay Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Central Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Southern Highlands Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'West Sepik Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'National Capital District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Morobe Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Manus Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Madang Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Gulf Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Hela');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PG', 'Jiwaka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Autonomous Region in Muslim Mindanao');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Northern Mindanao');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Mimaropa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Cagayan Valley');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Soccsksargen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Caraga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Cordillera Administrative Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Ilocos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Calabarzon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Western Visayas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Central Luzon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Central Visayas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Eastern Visayas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Zamboanga Peninsula');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Davao');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'Bicol');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PH', 'National Capital Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PK', 'Islamabad Capital Territory');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PK', 'Sindh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PK', 'Punjab');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PK', 'Khyber Pakhtunkhwa Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PK', 'Northern Areas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PK', 'Federally Administered Tribal Areas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PK', 'Balochistan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PK', 'Azad Kashmir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Lubelskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Malopolskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Mazowieckie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Podkarpackie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Podlaskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Swietokrzyskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Warminsko-Mazurskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Dolnoslaskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Lodzkie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Lubuskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Opolskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Pomorskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Slaskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Wielkopolskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Zachodniopomorskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PL', 'Wojewodztwo Kujawsko-Pomorskie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PM', 'Commune de Saint-Pierre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PM', 'Commune de Miquelon-Langlade');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Adjuntas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Aguada');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Aguadilla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Aguas Buenas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Aibonito');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Anasco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Arecibo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Arroyo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Barceloneta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Barranquitas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Bayamon Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Cabo Rojo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Caguas Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Camuy Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Canovanas Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Carolina Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Catano Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Cayey Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Ceiba Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Ciales Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Cidra Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Coamo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Comerio Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Corozal Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Culebra Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Dorado Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Fajardo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Florida Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Guanica Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Guayama Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Guayanilla Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Guaynabo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Gurabo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Hatillo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Hormigueros Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Humacao Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Municipio de Isabela');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Municipio de Jayuya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Juana Diaz Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Municipio de Juncos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Lajas Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Lares Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Las Marias Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Las Piedras Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Loiza Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Luquillo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Manati Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Maricao Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Maunabo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Mayagueez Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Moca Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Morovis Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Naguabo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Naranjito Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Orocovis Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Patillas Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Penuelas Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Ponce Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Rincon Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Quebradillas Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Rio Grande Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Sabana Grande Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Salinas Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'San German Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'San Juan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'San Lorenzo Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'San Sebastian Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Santa Isabel Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Toa Alta Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Toa Baja Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Trujillo Alto Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Utuado Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Vega Alta Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Vega Baja Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Villalba Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Yabucoa Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Yauco Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PR', 'Vieques Municipio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Lisboa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Leiria');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Castelo Branco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Beja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito da Guarda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Aveiro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Setubal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Santarem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Portalegre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Faro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Evora');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Madeira');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Viseu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Vila Real');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Viana do Castelo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito do Porto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Coimbra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Braganca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Distrito de Braga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PT', 'Azores');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Ngatpang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Sonsorol');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Kayangel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Hatohobei');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Aimeliik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Airai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Angaur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Koror');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Melekeok');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Ngaraard');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Ngchesar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Ngarchelong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Ngardmau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Ngeremlengui');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Ngiwal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PW', 'State of Peleliu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de la Cordillera');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Concepcion');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento Central');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Canindeyu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Caazapa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Caaguazu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento del Amambay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento del Alto Parana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Alto Paraguay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Asuncion');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Boqueron');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de San Pedro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Presidente Hayes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Paraguari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Neembucu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Misiones');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento de Itapua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('PY', 'Departamento del Guaira');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('QA', 'Baladiyat ash Shamal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('QA', 'Baladiyat al Khawr wa adh Dhakhirah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('QA', 'Baladiyat Umm Salal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('QA', 'Baladiyat ar Rayyan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('QA', 'Baladiyat ad Dawhah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('QA', 'Al Wakrah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('QA', 'Baladiyat az Za`ayin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RE', 'Reunion');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Tulcea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Timis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Teleorman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Suceava');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Prahova');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Mehedinti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Maramures');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Galati');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Dolj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Caras-Severin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Calarasi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Buzau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Bucuresti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Arges');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Arad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Alba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Ilfov');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Vrancea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Valcea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Vaslui');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Sibiu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Satu Mare');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Salaj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Olt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Neamt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Mures');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Iasi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Ialomita');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Hunedoara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Harghita');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Gorj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Giurgiu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Dambovita');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Covasna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Constanta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Cluj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Brasov');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Braila');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Botosani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Bistrita-Nasaud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Bihor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RO', 'Judetul Bacau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RS', 'Autonomna Pokrajina Vojvodina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RS', 'Central Serbia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Yaroslavskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Tatarstan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Tambovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Smolenskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Saratovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Samarskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Novgorodskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'North Ossetia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kirovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Ivanovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Ingushetiya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Chechenskaya Respublika');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Adygeya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Altay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Yevreyskaya Avtonomnaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kamtchatski Kray');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Zabaykal''skiy Kray');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Pskovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Perm Krai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Penzenskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Murmanskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Moskva');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Moskovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Mordoviya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kurskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Komi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Karachayevo-Cherkesiya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kaluzhskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kalmykiya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kaliningradskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kabardino-Balkarskaya Respublika');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Vladimirskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Sverdlovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Altayskiy Kray');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Primorskiy Kray');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Magadanskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Ryazanskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Orlovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Orenburgskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Lipetskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Leningradskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Sankt-Peterburg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Krasnodarskiy Kray');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Bryanskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Belgorodskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Bashkortostan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Yamalo-Nenetskiy Avtonomnyy Okrug');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kurganskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Krasnoyarskiy Kray');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Chelyabinskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Sakha (Yakutiya)');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Amurskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Chukotskiy Avtonomnyy Okrug');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Voronezhskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Vologodskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Volgogradskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Ulyanovsk Oblast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Udmurtskaya Respublika');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Tverskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Tul''skaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Stavropol''skiy Kray');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Rostovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Nenetskiy Avtonomnyy Okrug');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Mariy-El');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kostromskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Kareliya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Nizhegorodskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Dagestan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Chuvashskaya Respublika');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Astrakhanskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Arkhangel''skaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Tyumenskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Tyva');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Tomskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Omskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Novosibirskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Khanty-Mansiyskiy Avtonomnyy Okrug-Yugra');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Khakasiya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Kemerovskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Khabarovskiy Kray');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Irkutskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Respublika Buryatiya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RU', 'Sakhalinskaya Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RW', 'Eastern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RW', 'Kigali Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RW', 'Northern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RW', 'Western Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('RW', 'Southern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Al-Qassim Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Al Madinah al Munawwarah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Al Jawf');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Mintaqat al Hudud ash Shamaliyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Mintaqat al Bahah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Mintaqat Tabuk');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Mintaqat `Asir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Al Mintaqah ash Sharqiyah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Mintaqat ar Riyad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Mintaqat Najran');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Makkah Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Jizan Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SA', 'Mintaqat Ha''il');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Malaita Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Isabel Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Guadalcanal Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Central Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Temotu Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Makira-Ulawa Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Western Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Choiseul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Rennell and Bellona');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SB', 'Honiara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Takamaka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Saint Louis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Port Glaud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Pointe Larue');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Plaisance');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Mont Fleuri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Mont Buxton');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'English River');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Inner Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Grand Anse Mahe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Grand Anse Praslin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Glacis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Cascade');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Bel Ombre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Bel Air');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Beau Vallon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Baie Sainte Anne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Baie Lazare');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Anse Royale');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Anse Etoile');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Anse Boileau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Anse aux Pins');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Les Mamelles');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Roche Caiman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SC', 'Au Cap');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Red Sea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Al Jazirah State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Al Qadarif State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'White Nile');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Blue Nile');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Western Darfur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Southern Darfur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Southern Kordofan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Kassala State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'River Nile');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Northern Darfur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Northern Kordofan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Sinnar State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Northern');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Khartoum');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Eastern Darfur State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SD', 'Central Darfur State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Norrbotten');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Vaestmanlands Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Vaesternorrlands Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Vaesterbottens Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'OEstergoetlands Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Kronoberg');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Gotland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Gaevleborgs Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Soedermanlands Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Kalmar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Joenkoepings Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Jaemtlands Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Halland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Skane Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Vaestra Goetalands Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Vaermlands Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Uppsala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Stockholm');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'OErebro Laen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Dalarna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SE', 'Blekinge');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SG', 'Central Singapore Community Development Council');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SG', 'North East Community Development Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SG', 'South East Community Development Council');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SG', 'South West Community Development Council');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SG', 'North West Community Development Council');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SH', 'Ascension');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SH', 'Tristan da Cunha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SH', 'Saint Helena');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Zalec');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Zagorje ob Savi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Vrhnika');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Trzic');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Trebnje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Trbovlje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Tolmin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Velenje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Smarje pri Jelsah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Slovenske Konjice');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Slovenska Bistrica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Slovenj Gradec');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Skofja Loka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sezana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Sevnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sentjur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Ribnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Radovljica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Radlje ob Dravi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Ptuj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Postojna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Piran');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Ormoz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Mestna Obcina Novo mesto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Nova Gorica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Murska Sobota');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Mozirje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Metlika');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Maribor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Logatec');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Ljutomer');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Litija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Lenart');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Lasko');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Krsko');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kranj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Koper');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Kocevje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kamnik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Jesenice');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Izola');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Ilirska Bistrica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Idrija');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Hrastnik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Grosuplje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Gornja Radgona');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Dravograd');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Domzale');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Crnomelj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Cerknica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Celje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Brezice');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Ajdovscina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Hrpelje-Kozina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Divaca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Pivka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Loska Dolina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Loski Potok');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Osilnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Velike Lasce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Skofljica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Ig');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Brezovica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Borovnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Vipava');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Komen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Miren-Kostanjevica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Brda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kanal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Ziri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Cerkno');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Zelezniki');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Gorenja Vas-Poljane');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Dobrova-Polhov Gradec');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Kobarid');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Bovec');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Bohinj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Bled');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Naklo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kranjska Gora');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Preddvor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Cerklje na Gorenjskem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sencur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Vodice');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Medvode');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Menges');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Dol pri Ljubljani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Moravce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Gornji Grad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Luce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Ravne na Koroskem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Mezica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Muta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Vuzenica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Crna na Koroskem');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Ljubno');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sostanj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Smartno ob Paki');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Lukovica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Radece');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Ivancna Gorica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Dobrepolje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Semic');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sentjernej');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Skocjan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Store');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Vojnik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Vitanje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Zrece');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Mislinja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Ruse');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kungota');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sentilj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Pesnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Duplek');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Race-Fram');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Starse');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Kidricevo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Majsperk');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Videm');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Rogaska Slatina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Rogatec');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Podcetrtek');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kozje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Gorisnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Zavrc');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Dornava');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Jursinci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sveti Jurij ob Scavnici');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Radenci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Puconci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Rogasovci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kuzma');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Gornji Petrovci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Moravske Toplice');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kobilje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Beltinci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Turnisce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Odranci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Crensovci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Nazarje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Mestna Obcina Ljubljana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Zirovnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Jezersko');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Solcava');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Komenda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Horjul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sempeter-Vrtojba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Bloke');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sodrazica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Trzin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Prevalje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Vransko');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Tabor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Braslovce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Polzela');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Prebold');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kostel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Zuzemberk');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Dolenjske Toplice');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Mirna Pec');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Bistrica ob Sotli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Dobje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Dobrna');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Oplotnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Podvelka');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Ribnica na Pohorju');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Lovrenc na Pohorju');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Selnica ob Dravi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Hoce-Slivnica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Miklavz na Dravskem Polju');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Hajdina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Zetale');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Podlehnik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Markovci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Destrnik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Trnovska vas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sveti Andraz v Slovenskih Goricah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Cerkvenjak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Benedikt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Sveta Ana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Krizevci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Verzej');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Velika Polana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Lendava');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Dobrovnik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Tisina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Cankova');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Grad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Hodos');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Razkrizje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Smartno pri Litiji');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Salovci');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Apace');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Cirkulane');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Kostanjevica na Krki');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Log-Dragomer');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Makole');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Mokronog-Trebelno');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Poljcane');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Recica ob Savinji');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Rence-Vogrsko');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sredisce ob Dravi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Straza');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Sveta Trojica v Slovenskih Goricah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sveti Tomaz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Sentrupert');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Obcina Smarjeske Toplice');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Sveti Jurij v Slovenskih Goricah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SI', 'Gorje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SJ', 'Jan Mayen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SJ', 'Svalbard');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SK', 'Banskobystricky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SK', 'Bratislavsky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SK', 'Nitriansky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SK', 'Trenciansky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SK', 'Trnavsky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SK', 'Kosicky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SK', 'Presovsky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SK', 'Zilinsky kraj');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SL', 'Northern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SL', 'Eastern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SL', 'Western Area');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SL', 'Southern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SM', 'Serravalle');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SM', 'Chiesanuova');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SM', 'Castello di San Marino Citta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SM', 'Castello di Acquaviva');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SM', 'Castello di Borgo Maggiore');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SM', 'Castello di Domagnano');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SM', 'Castello di Faetano');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SM', 'Castello di Fiorentino');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SM', 'Castello di Montegiardino');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Ziguinchor');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Matam');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Fatick');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Diourbel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Dakar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Region de Kaffrine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Region de Kedougou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Region de Sedhiou');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Region de Thies');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Tambacounda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Saint-Louis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Louga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Kolda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SN', 'Kaolack');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Shabeellaha Hoose');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Shabeellaha Dhexe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Sanaag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Nugaal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Jubbada Hoose');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Jubbada Dhexe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Hiiraan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Awdal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Sool');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Woqooyi Galbeed');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Togdheer');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Mudug');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Gedo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Galguduud');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Bay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Bari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Banaadir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SO', 'Gobolka Bakool');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Sipaliwini');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Saramacca');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Paramaribo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Para');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Nickerie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Marowijne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Coronie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Commewijne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Brokopondo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SR', 'Distrikt Wanica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ST', 'Sao Tome');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ST', 'Principe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de La Union');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de La Paz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de La Libertad');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de Usulutan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de Sonsonate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de San Vicente');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de Santa Ana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de San Salvador');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de San Miguel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de Morazan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de Cuscatlan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de Chalatenango');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de Cabanas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SV', 'Departamento de Ahuachapan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Ar-Raqqah Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Quneitra Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Latakia Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Al-Hasakah Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Tartus Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Idlib Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Homs Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Hama Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Aleppo Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Muhafazat Rif Dimashq');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Deir ez-Zor Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Daraa Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'Damascus Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SY', 'As-Suwayda Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SZ', 'Shiselweni District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SZ', 'Manzini District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SZ', 'Lubombo District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('SZ', 'Hhohho District');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Wadi Fira Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Moyen-Chari Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Mayo-Kebbi East Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Logone Oriental Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Logone Occidental Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Lac Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Chari-Baguirmi Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Salamat Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Ouaddai Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Tandjile Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Kanem Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Guera Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Batha Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Borkou Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Hadjer-Lamis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Mandoul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Mayo-Kebbi West Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Ville de N''Djamena');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Barh el Gazel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Sila');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Tibesti Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Ennedi-Ouest');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TD', 'Ennedi-Est');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TF', 'Archipel des Crozet');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TF', 'Archipel des Kerguelen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TF', 'Iles Saint-Paul et Nouvelle-Amsterdam');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TF', 'Iles Eparses de l''ocean Indien');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TF', 'La Terre-Adelie');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TG', 'Centrale');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TG', 'Savanes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TG', 'Plateaux');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TG', 'Maritime');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TG', 'Kara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Uthai Thani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Mae Hong Son');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Lamphun');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Lampang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Krabi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Kanchanaburi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Kamphaeng Phet');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nong Khai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Narathiwat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nakhon Si Thammarat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nakhon Sawan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nakhon Ratchasima');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nakhon Phanom');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nakhon Pathom');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nakhon Nayok');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Mukdahan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Maha Sarakham');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Lop Buri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Loei');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Bangkok');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Khon Kaen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Udon Thani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Prachin Buri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Ubon Ratchathani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Amnat Charoen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nong Bua Lamphu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Sa Kaeo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Trang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Tak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Surat Thani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Sukhothai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Ratchaburi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Ranong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Prachuap Khiri Khan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Phuket Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Phetchaburi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Phangnga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Chumphon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Chiang Rai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Chiang Mai Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Yasothon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Kalasin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Chon Buri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Chanthaburi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Chaiyaphum');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Chai Nat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Chachoengsao');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Buriram');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Samut Songkhram');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Samut Sakhon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Samut Prakan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Sakon Nakhon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Roi Et');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Rayong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Phra Nakhon Si Ayutthaya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Phrae');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Phitsanulok');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Phichit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Phetchabun');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Phayao');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Phatthalung');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Pattani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Pathum Thani');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Nonthaburi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Ang Thong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Bueng Kan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Yala');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Uttaradit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Trat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Surin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Suphan Buri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Songkhla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Sisaket');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Sing Buri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Satun');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TH', 'Changwat Sara Buri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TJ', 'Viloyati Sughd');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TJ', 'Viloyati Mukhtori Kuhistoni Badakhshon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TJ', 'Viloyati Khatlon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TJ', 'Region of Republican Subordination');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TJ', 'Dushanbe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TK', 'Nukunonu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TK', 'Fakaofo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TK', 'Atafu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TM', 'Balkan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TM', 'Ahal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TM', 'Dasoguz Welayaty');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TM', 'Mary');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TM', 'Lebap');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Zaghouan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Tunis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Tozeur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Tataouine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Kebili');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gafsa Governorate');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Gabes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Nabeul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Bizerte');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Beja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de l''Ariana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Kairouan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Kasserine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Monastir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Mahdia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Kef');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Sousse');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Siliana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Sidi Bouzid');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Medenine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Jendouba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Manouba');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Sfax');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TN', 'Gouvernorat de Ben Arous');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TO', 'Vava`u');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TO', 'Tongatapu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TO', 'Ha`apai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TO', 'Eua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TO', 'Niuas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Yozgat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kayseri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Gaziantep');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Eskisehir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Erzurum');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Erzincan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Elazig');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Bitlis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Bingoel');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Bilecik');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Balikesir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Trabzon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Tokat');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Tekirdag');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kastamonu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kars');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Istanbul');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Cankiri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Canakkale');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Bursa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Bolu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Sivas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Siirt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Konya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kirsehir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Hatay');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Hakkari');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Burdur');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Agri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Afyonkarahisar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Adiyaman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Adana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Osmaniye');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Igdir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Aksaray');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Batman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Karaman');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kirikkale');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Sirnak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kilis');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Zonguldak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kocaeli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kirklareli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Edirne');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Corum');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Van');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Usak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Sanliurfa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Tunceli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Nigde');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Nevsehir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Mus');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Mugla');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Mardin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Manisa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Malatya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kuetahya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Kahramanmaras');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Izmir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Isparta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Mersin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Diyarbakir');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Denizli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Aydin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Antalya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Ankara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Sinop');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Samsun');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Sakarya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Rize');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Ordu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Guemueshane');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Giresun');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Artvin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Amasya');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Bartin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Karabuek');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Yalova');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Ardahan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Bayburt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TR', 'Duezce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Tobago');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'San Fernando');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'City of Port of Spain');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Mayaro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Arima');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Chaguanas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Couva-Tabaquite-Talparo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Diego Martin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Eastern Tobago');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Penal/Debe');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Princes Town');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Point Fortin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Sangre Grande');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Siparia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'San Juan/Laventille');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TT', 'Tunapuna/Piarco');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TV', 'Nui');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TV', 'Nanumea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TV', 'Funafuti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TV', 'Niutao');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TV', 'Nanumanga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TV', 'Vaitupu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TV', 'Nukufetau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TV', 'Nukulaelae');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TW', 'Fukien');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TW', 'Kaohsiung');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TW', 'Taipei');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TW', 'Taiwan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Kagera Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Zanzibar Urban/West Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Zanzibar North Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Zanzibar Central/South Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Kilimanjaro Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Kigoma Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Mbeya Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Mara Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Lindi Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Simiyu Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Geita Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Katavi Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Njombe Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Mwanza Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Morogoro Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Arusha Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Manyara Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Ruvuma Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Mtwara Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Tanga Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Tabora Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Singida Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Shinyanga Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Rukwa Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Coast Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Pemba South Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Pemba North Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Iringa Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Dodoma Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('TZ', 'Dar es Salaam Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Ternopil''s''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Odes''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Kirovohrads''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Khmel''nyts''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Khersons''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Kharkivs''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Sums''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Mykolayivs''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Ivano-Frankivs''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Zhytomyrs''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Zaporiz''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Zakarpattia Oblast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Misto Sevastopol''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'L''vivs''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Luhans''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Donets''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Dnipropetrovska Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Volyns''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Vinnyts''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Rivnens''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Poltavs''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Kyiv Oblast');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Misto Kyyiv');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Autonomous Republic of Crimea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Chernivets''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Chernihivs''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UA', 'Cherkas''ka Oblast''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UG', 'Eastern Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UG', 'Northern Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UG', 'Western Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UG', 'Central Region');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UM', 'Wake Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UM', 'Navassa Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UM', 'Baker Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UM', 'Howland Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UM', 'Jarvis Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UM', 'Johnston Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UM', 'Kingman Reef');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UM', 'Midway Islands');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UM', 'Palmyra Atoll');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Georgia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Maryland');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Mississippi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Oklahoma');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Maine');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Ohio');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Rhode Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'California');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Montana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Alaska');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Arkansas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'District of Columbia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Florida');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'West Virginia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Indiana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Nebraska');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'New Hampshire');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Vermont');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Colorado');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Utah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Wyoming');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Delaware');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Louisiana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Missouri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'North Carolina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'South Carolina');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Connecticut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Illinois');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Minnesota');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'New Jersey');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Wisconsin');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Nevada');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Arizona');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Idaho');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'North Dakota');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Washington');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Hawaii');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Kentucky');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Massachusetts');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Pennsylvania');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Virginia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Kansas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Tennessee');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Texas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Alabama');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Iowa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Michigan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'New York');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'New Mexico');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'Oregon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('US', 'South Dakota');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Treinta y Tres');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Tacuarembo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Soriano');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de San Jose');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Salto');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Rocha');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Rivera');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Rio Negro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Florida');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Flores');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Durazno');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Colonia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Cerro Largo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Canelones');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Artigas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Paysandu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Montevideo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Maldonado');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UY', 'Departamento de Lavalleja');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Toshkent Viloyati');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Toshkent Shahri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Sirdaryo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Navoiy Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Namangan Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Xorazm Viloyati');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Jizzakh Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Fergana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Andijan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Karakalpakstan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Surxondaryo Viloyati');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Samarqand Viloyati');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Qashqadaryo Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('UZ', 'Bukhara Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VC', 'Parish of Saint Patrick');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VC', 'Parish of Saint George');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VC', 'Parish of Saint David');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VC', 'Parish of Saint Andrew');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VC', 'Grenadines');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VC', 'Parish of Charlotte');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Portuguesa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Carabobo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Bolivar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Vargas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Trujillo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Tachira');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Sucre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Lara');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Delta Amacuro');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Cojedes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Zulia');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Yaracuy');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Merida');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Nueva Esparta');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Monagas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Miranda');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Guarico');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Dependencias Federales');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Distrito Capital');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Falcon');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Barinas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Aragua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Apure');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Anzoategui');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VE', 'Estado Amazonas');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VI', 'Saint Croix Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VI', 'Saint John Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VI', 'Saint Thomas Island');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Nghe An');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Ninh Binh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Ninh Thuan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Soc Trang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Tra Vinh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Tuyen Quang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Vinh Long');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Yen Bai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Lao Cai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Tien Giang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Thua Thien-Hue');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Kon Tum');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Thanh Hoa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Thai Binh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Tay Ninh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Son La');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Quang Tri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Quang Ninh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Quang Ngai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Quang Binh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Phu Yen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Hoa Binh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Ho Chi Minh City');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Ha Tinh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Ha Giang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Gia Lai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Thanh Pho Ha Noi');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Thanh Pho Can Tho');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Thanh Pho Hai Phong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Binh Thuan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Dong Thap');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Lai Chau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Kien Giang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Khanh Hoa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Binh Dinh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Ben Tre');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Hau Giang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Dong Nai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Dak Lak');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Ba Ria-Vung Tau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Long An');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Lang Son');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Lam Dong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Cao Bang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'An Giang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Dak Nong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Huyen Dien Bien');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Bac Ninh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Bac Giang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Thanh Pho Da Nang');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Binh Duong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Binh Phuoc');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Thai Nguyen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Quang Nam');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Phu Tho');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Nam Dinh');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Ha Nam');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Bac Kan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Bac Lieu');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Ca Mau');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Hai Duong');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Hung Yen');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VN', 'Tinh Vinh Phuc');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VU', 'Torba Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VU', 'Malampa Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VU', 'Penama Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VU', 'Shefa Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VU', 'Tafea Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('VU', 'Sanma Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WF', 'Circonscription d''Uvea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WF', 'Circonscription de Sigave');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WF', 'Circonscription d''Alo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Vaisigano');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Va`a-o-Fonoti');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Tuamasaga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Satupa`itea');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Palauli');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Gagaifomauga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Gaga''emauga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Fa`asaleleaga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Atua');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'Aiga-i-le-Tai');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('WS', 'A''ana');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Vushtrri');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Vitise');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Ferizajt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Mitrovices');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Therandes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Skenderajt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Prizren');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Prishtines');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Podujevo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Pejes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Orahovac');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Lipjan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Leposaviqit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Kamenica');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Klines');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Kacanikut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Istogut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Drenasit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Gjilanit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Dragashit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Decanit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Gjakoves');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Kosovo Polje');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Opstina Strpce');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Shtimes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Novo Brdo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Obiliqit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Malisheves');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Zubin Potokut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Opstina Zvecan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Gracanices');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Hani i Elezit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Junikut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Kllokotit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Mamushes');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Parteshit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('XK', 'Komuna e Ranillugut');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat Ta`izz');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat Dhamar');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat ad Dali`');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat `Amran');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat Hajjah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Ibb');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat Lahij');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Amanat Al Asimah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat al Jawf');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat Hadramawt');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat Ma''rib');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Al Mahwit');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat al Hudaydah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat al Bayda''');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat `Adan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat Abyan');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Shabwah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Sanaa');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat Sa`dah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Muhafazat Raymah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('YE', 'Al Mahrah');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZA', 'Province of KwaZulu-Natal');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZA', 'Eastern Cape');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZA', 'Gauteng');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZA', 'Mpumalanga');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZA', 'Province of Northern Cape');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZA', 'Limpopo');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZA', 'Province of North West');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZA', 'Province of the Western Cape');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZA', 'Free State');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZM', 'North-Western Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZM', 'Northern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZM', 'Central Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZM', 'Western Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZM', 'Southern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZM', 'Eastern Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZM', 'Copperbelt Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZM', 'Lusaka Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZM', 'Luapula Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Midlands Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Matabeleland South Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Matabeleland North Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Masvingo Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Mashonaland West Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Mashonaland East Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Mashonaland Central Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Manicaland Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Bulawayo Province');
INSERT INTO [Lookup].[State] (Code, Name) VALUES ('ZW', 'Harare Province');





CREATE TABLE [dbo].[AspNetUsers](
	[Id] [nvarchar](128) NOT NULL,
	[Email] [nvarchar](256) NULL,
	[EmailConfirmed] [bit] NOT NULL,
	[PasswordHash] [nvarchar](max) NULL,
	[SecurityStamp] [nvarchar](max) NULL,
	[PhoneNumber] [nvarchar](max) NULL,
	[PhoneNumberConfirmed] [bit] NOT NULL,
	[TwoFactorEnabled] [bit] NOT NULL,
	[LockoutEndDateUtc] [datetime] NULL,
	[LockoutEnabled] [bit] NOT NULL,
	[AccessFailedCount] [int] NOT NULL,
	[UserName] [nvarchar](256) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetUsers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


CREATE TABLE [dbo].[AspNetRoles](
	[Id] [nvarchar](128) NOT NULL,
	[Name] [nvarchar](256) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetRoles] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[AspNetUserLogins](
	[LoginProvider] [nvarchar](128) NOT NULL,
	[ProviderKey] [nvarchar](128) NOT NULL,
	[UserId] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetUserLogins] PRIMARY KEY CLUSTERED 
(
	[LoginProvider] ASC,
	[ProviderKey] ASC,
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[AspNetUserLogins]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserLogins_dbo.AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[AspNetUserLogins] CHECK CONSTRAINT [FK_dbo.AspNetUserLogins_dbo.AspNetUsers_UserId]
GO



CREATE TABLE [dbo].[AspNetUserClaims](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](128) NOT NULL,
	[ClaimType] [nvarchar](max) NULL,
	[ClaimValue] [nvarchar](max) NULL,
 CONSTRAINT [PK_dbo.AspNetUserClaims] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[AspNetUserClaims]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserClaims_dbo.AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[AspNetUserClaims] CHECK CONSTRAINT [FK_dbo.AspNetUserClaims_dbo.AspNetUsers_UserId]
GO


CREATE TABLE [dbo].[AspNetUserRoles](
	[UserId] [nvarchar](128) NOT NULL,
	[RoleId] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetUserRoles] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetRoles_RoleId]
GO

ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetUsers_UserId]
GO



---Add users---


INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(1,'darklord@allyis.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'darklord@allyis.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b501',0,0); 

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES (1, 'Sauron', 'Maia', '9/9/90', '123 Fake Street', 'Chicago', 'Illinios', 'United States', 999999, 'darklord@allyis.com', '6309999999');


INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(2,'test@allyis.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'test@allyis.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b502',0,0); 

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES (2, 'Faking', 'Faker', '1/1/1900', '123 False Street', 'Aurora', 'Illinois', 'United States', 999999, 'test@allyis.com', '6309999999');



INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(3,'test@gmail.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'test@gmail.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b503',0,0); 

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(3, 'Mongrel', 'Mongrel', '1/1/1900', '123 Worthless Street', 'Aurora', 'Illinois', 'United States', 999999, 'test@gmail.com', '6309999999'); 




INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(4,'testing@allyis.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'testing@allyis.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b504',0,0); 

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(4, 'Cthullu', 'Old One', '1/1/1900', '123 Blacath Dr.', 'Ryleth', 'Austerland', 'Iceland', 999999, 'testing@allyis.com', '6309999999'); 




INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(5,'testing@gmail.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'testing@gmail.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b505',0,0); 

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(5, 'Uncaring', 'Nihlist', '1/1/1990', '123 Who Cares Street', 'Chicago', 'Illinios', 'United States', 999999, 'testing@gmail.com', '6309999999'); 




INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(6,'tester@gmail.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'tester@gmail.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b506',0,0);

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(6, 'Unlimited', 'Power', '1/1/1900', '123 Death Star', 'Sandwhich', 'Illinois', 'United States', 999999, 'tester@gmail.com', '6309999999');



INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(666,'emperor@gmail.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'emperor@gmail.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b506',0,0);

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(666, 'Sheev', 'Palpatine', '1/1/1900', '123 Death Star', 'Baleony', 'Illinois', 'United States', 999999, 'emperor@gmail.com', '6309999999');



INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(7,'notajedi@gmail.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'notajedi@gmail.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b506',0,0);

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(7, 'Obi-Wan', 'NotSecretlyAJediKenobi', '1/1/1900', '123 Hive', 'Scum and Villiany', 'Illinois', 'United States', 999999, 'notajedi@gmail.com', '6309999999');



INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(8,'fireysword@gmail.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'fireysword@gmail.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b506',0,0);

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(8, 'Ur', 'Iel', '1/1/1900', '123 Gate', 'Eden', 'Illinois', 'United States', 999999, 'fireysword@gmail.com', '6309999999');




INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(9,'cheesemaker@gmail.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'cheesemaker@gmail.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b506',0,0);

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(9, 'Sheo', 'Gorath', '1/1/1900', '123 Beards', 'New Sheoth', 'Illinois', 'United States', 999999, 'cheesemaker@gmail.com', '6309999999');




INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(10,'manymasks@gmail.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'manymasks@gmail.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b506',0,0);

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(10, 'Nyarlathotep', 'Of a Thousand Faces', '1/1/1900', '123 Everywhere', 'Everywhere', 'Illinois', 'United States', 999999, 'manymasks@gmail.com', '6309999999');



INSERT INTO [dbo].[AspNetUsers] (Id, Email, EmailConfirmed, PasswordHash, UserName, PhoneNumberConfirmed, TwoFactorEnabled,SecurityStamp, LockoutEnabled, AccessFailedCount ) 
	Values(11,'twoheadsbetter@gmail.com', 1, 'AJGlYeP2PNtXrF6kjyAZzsGqS2ow4zcf/cVqRgsj8Idr+TaBgPXJI4B/R80GJmYn4A==', 'twoheadsbetter@gmail.com',1,0,'2e7b0b70-0786-42ea-af61-597bb122b506',0,0);

INSERT INTO [Auth].[User] (UserId, FirstName, LastName, DateOfBirth, Address, City, State, Country, ZipCode, Email, PhoneNumber)
	VALUES(11, 'Two Headed', 'Thing', '1/1/1900', '123 Mad Science Lane', 'B-Movie', 'Illinois', 'United States', 999999, 'twoheadsbetter@gmail.com', '6309999999');












----Insert Test Organization ---


Insert Into [Auth].[Organization] (Name, DateCreated, IsActive, AccessCode, Subdomain) Values ('Test Org', GETDATE(), 1, '1a', 'stringoftesting'); 


Insert Into [Auth].[Organization] (Name, DateCreated, IsActive, AccessCode, Subdomain) Values ('A Secretive Organization', GETDATE(), 1, '2a', 'stringofmystery'); 

Insert Into [Auth].[Organization] (Name, DateCreated, IsActive, AccessCode, Subdomain) Values ('Who needs an extra body anyway?', GETDATE(), 1, '3a', 'twoheadsonebody'); 


Insert Into [Auth].[Organization] (Name, DateCreated, IsActive, AccessCode, Subdomain) Values ('Cosmic Messages', GETDATE(), 1, '4a', 'outerealmsmessages'); 


---Insert Test Customer---
INSERT Into [Shared].[Customer] (Name, ContactEmail, Address, City, State, Country, ZipCode, ContactPhoneNumber, OrganizationId) Values('Test Customer', 'test@gmail.com', 'Test Street', 'Test City', 
'Illinios', 'United States', 999999, '6309999999', 1); 

---Insert Test Project---

Insert Into [Shared].[Project] (OrganizationId, CustomerId, Name) Values (1, 1, 'Test Project'); 


---Add users to organization----


INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(1,1,2,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(1,2,2,1,GETDATE());	 	 

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(2,1,1,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(3,1,1,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(4,1,1,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(5,1,1,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(6,1,1,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(666,2,2,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(7,2,1,1,GETDATE());
	
INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(7,1,1,1,GETDATE());		
		

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(8,2,1,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(9,2,1,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(10,2,1,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(10,4,2,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(11,2,1,1,GETDATE());

INSERT INTO [Auth].[OrganizationUser](UserId, OrganizationId, OrgRoleId, IsActive, DateAdded)
	Values(11,3,2,1,GETDATE());


--Subscribe organization and users--
INSERT INTO [Billing].[Subscription](OrganizationId, SKUId, NumberOfUsers) VALUES (1, 1, 5);

INSERT INTO [Billing].[Subscription](OrganizationId, SKUId, NumberOfUsers) VALUES (4, 1, 5);



INSERT INTO [Billing].[SubscriptionUser] (SubscriptionId, UserId, ProductRoleId, DateAdded)
		VALUES (1, 1, 3, GETDATE());

INSERT INTO [Billing].[SubscriptionUser] (SubscriptionId, UserId, ProductRoleId, DateAdded)
		VALUES (1, 2, 2, GETDATE());

INSERT INTO [Billing].[SubscriptionUser] (SubscriptionId, UserId, ProductRoleId, DateAdded)
		VALUES (1, 3, 2, GETDATE());

INSERT INTO [Billing].[SubscriptionUser] (SubscriptionId, UserId, ProductRoleId, DateAdded)
		VALUES (1, 4, 2, GETDATE());

INSERT INTO [Billing].[SubscriptionUser] (SubscriptionId, UserId, ProductRoleId, DateAdded)
		VALUES (1, 5, 2, GETDATE());

INSERT INTO [Billing].[SubscriptionUser] (SubscriptionId, UserId, ProductRoleId, DateAdded)
		VALUES (2, 10, 3, GETDATE());
