USE [AllyisApps.Database] 
GO 

 GO 
CREATE SCHEMA [Auth]

 GO 
CREATE SCHEMA [Billing]

 GO 
CREATE SCHEMA Customer

 GO 
CREATE SCHEMA [Lookup]

 GO 
CREATE SCHEMA [Org]

 GO 
CREATE SCHEMA [OrgUser]

 GO 
CREATE SCHEMA [Shared]
 GO 
CREATE SCHEMA [TimeTracker]

 GO 
CREATE SCHEMA [User]
