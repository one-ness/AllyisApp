USE [AllyisApps.Database] 
GO 
CREATE LOGIN [aaUser] WITH PASSWORD ='BlueSky23#'; 
GO 
CREATE USER [aaUser] FOR login [aaUser] WITH DEFAULT_SCHEMA=[db_owner]; 
GRANT SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: [Auth] TO [aaUser]; 
GRANT SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: [Billing] TO [aaUser]; 
GRANT SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: Customer TO [aaUser]; 
GRANT SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: [Lookup] TO [aaUser]; 
GRANT SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: [Org] TO [aaUser]; 
GRANT SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: [OrgUser] TO [aaUser]; 
GRANT SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: [Shared] TO [aaUser]; 
GRANT SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: [TimeTracker] TO [aaUser]; 
GRANT SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: [User] TO [aaUser]; 
GRANT ALTER, REFERENCES, SELECT, UPDATE, DELETE, INSERT, Execute on SCHEMA :: [dbo] TO [aaUser]; 
GRANT TAKE OWNERSHIP on SCHEMA :: [dbo] to [aaUser]; 
Grant CREATE TABLE TO [aaUser]
 GO 
