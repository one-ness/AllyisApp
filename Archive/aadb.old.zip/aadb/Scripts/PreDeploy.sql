﻿/*
 Pre-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be executed before the build script.	
 Use SQLCMD syntax to include a file in the pre-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the pre-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
DELETE FROM [TimeTracker].[TimeEntry];
DBCC CHECKIDENT('TimeTracker.TimeEntry', RESEED, 0);
DELETE FROM [Auth].[InvitationSubRole];
DELETE FROM[Auth].[Invitation];
DBCC CHECKIDENT('Auth.Invitation', RESEED, 0);
DELETE FROM [TimeTracker].[Holiday];
DBCC CHECKIDENT('TimeTracker.Holiday', RESEED, 0);
DELETE FROM [TimeTracker].[PayClass];
DBCC CHECKIDENT('TimeTracker.PayClass', RESEED, 0);
DELETE FROM [TimeTracker].[Setting];
DELETE FROM [Crm].[ProjectUser];
DELETE FROM [Crm].[Project];
DBCC CHECKIDENT('Crm.Project', RESEED, 0);
DELETE FROM [Crm].[Customer];
DBCC CHECKIDENT('Crm.Customer', RESEED, 0);
DELETE FROM [Billing].[SubscriptionUser];
DELETE FROM [Billing].[Subscription];
DBCC CHECKIDENT('Billing.Subscription', RESEED, 0);
DELETE FROM [Auth].[OrganizationUser];
DELETE FROM [Auth].[User];
DELETE FROM [Billing].[StripeOrganizationCustomer];
DELETE FROM [Auth].[Organization];
DELETE FROM [Lookup].[State];
DBCC CHECKIDENT('Lookup.State', RESEED, 0);
DELETE FROM [Lookup].[Country];
DBCC CHECKIDENT('Lookup.Country', RESEED, 0);
DELETE FROM [Auth].[ProductRole];
DBCC CHECKIDENT('Auth.ProductRole', RESEED, 0);
DELETE FROM [Billing].[Sku];
DBCC CHECKIDENT('Billing.Sku', RESEED, 0);
DELETE FROM [Billing].[Product];
DBCC CHECKIDENT('Billing.Product', RESEED, 0);
DELETE FROM [Auth].[OrgRole];