﻿IF (EXISTS ( SELECT * FROM tempdb.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '#Tmp%'))
BEGIN
	DROP TABLE #Tmp;
END
IF (EXISTS ( SELECT * FROM tempdb.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '#Vars%'))
BEGIN
	DROP TABLE #Vars;
END
IF (EXISTS ( SELECT * FROM tempdb.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '#CustomerCompares%'))
BEGIN
	DROP TABLE #CustomerCompares;
END
IF (EXISTS ( SELECT * FROM tempdb.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '#ProjectCompares%'))
BEGIN
	DROP TABLE #ProjectCompares;
END

PRINT 'Duplicate data for Travis'

DECLARE @EmailSuffix nvarchar(40) = '.Travis.com';
DECLARE @UserIdSuffix INT = 0;
DECLARE @SubdomainSuffix nvarchar(40) = 'travis';
:r .\DuplicateTestDataProc.sql

IF (EXISTS ( SELECT * FROM tempdb.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '#Tmp%'))
BEGIN
	DROP TABLE #Tmp;
END
IF (EXISTS ( SELECT * FROM tempdb.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '#Vars%'))
BEGIN
	DROP TABLE #Vars;
END
IF (EXISTS ( SELECT * FROM tempdb.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '#CustomerCompares%'))
BEGIN
	DROP TABLE #CustomerCompares;
END
IF (EXISTS ( SELECT * FROM tempdb.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '#ProjectCompares%'))
BEGIN
	DROP TABLE #ProjectCompares;
END

PRINT 'Dont Duplicate data for Orlan'

DECLARE @EmailSuffix nvarchar(40) = '.Orlan.com';
DECLARE @UserIdSuffix INT = 9299;
DECLARE @SubdomainSuffix nvarchar(40) = 'orlan'
