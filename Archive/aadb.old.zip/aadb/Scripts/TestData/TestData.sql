﻿:r .\Auth.Organization.Table.sql
PRINT 'Organization Complete'
:r .\Billing.Subscription.Table.sql
PRINT 'Subscription Complete'
:r .\Auth.User.Table.sql
PRINT 'User Complete'
:r .\Auth.OrganizationUser.Table.sql
PRINT 'OrganizationUser Complete'
:r .\Billing.OrganizationCustomer.Table.sql
PRINT 'OrganizationCustomer Complete'
:r .\Billing.SubscriptionUser.Table.sql
PRINT 'SubscriptionUser Complete'
:r .\Shared.Customer.Table.sql
PRINT 'Customer Complete'
:r .\Shared.Project.Table.sql
PRINT 'Project Complete'
:r .\Shared.ProjectUser.Table.sql
PRINT 'Project User Complete'
:r .\TimeTracker.TimeEntry.Table.sql
PRINT 'TimeEntry Complete'
:r .\TimeTracker.Settings.Table.sql
PRINT 'Settings Complete'