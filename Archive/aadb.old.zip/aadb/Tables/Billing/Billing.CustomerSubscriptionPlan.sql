﻿CREATE TABLE [Billing].[CustomerSubscriptionPlan]
(
	[StripeTokenCustId] NVARCHAR(50) NOT NULL , 
    [StripeTokenSubID] NCHAR(50) NOT NULL PRIMARY KEY, 
	[NumberofUsers] int NOT NULL, 
	[Price] INT NOT NULL, 
    [ProductId] INT NOT NULL, 
    [IsActive] BIT NOT NULL, 
    [OrganizationId] INT NOT NULL, 
    [CreatedUTC] DATETIME2(0) NOT NULL DEFAULT GETUTCDATE(), 
    [ModifiedUTC] DATETIME2(0) NOT NULL DEFAULT GETUTCDATE(), 
    CONSTRAINT [FK_CustomerSubscriptionPlan_Product] FOREIGN KEY ([ProductId]) REFERENCES [Billing].[Product]([ProductId]), 
    CONSTRAINT [FK_CustomerSubscriptionPlan_Organization] FOREIGN KEY ([OrganizationId]) REFERENCES [Auth].[Organization]([OrganizationId])
	) 

	GO
CREATE TRIGGER trg_update_CustomerSubscriptionPlan ON [Billing].[CustomerSubscriptionPlan] FOR UPDATE AS
BEGIN
	UPDATE [Billing].[CustomerSubscriptionPlan] SET [ModifiedUTC] = CONVERT(DATETIME2(0), GETUTCDATE()) FROM [Billing].[CustomerSubscriptionPlan] INNER JOIN [deleted] [d] ON [CustomerSubscriptionPlan].[StripeTokenSubID] = [d].[StripeTokenSubID];
END
GO