﻿CREATE TABLE [Auth].[OrgRole]
(
	[OrgRoleId] INT NOT NULL PRIMARY KEY,
	[Name] NVARCHAR(100) NOT NULL, 
    [IsActive] BIT NOT NULL DEFAULT 1 
)
GO
