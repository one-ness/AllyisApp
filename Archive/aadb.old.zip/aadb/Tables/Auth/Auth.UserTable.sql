﻿CREATE TYPE [Auth].[UserTable] AS TABLE
(
	userId INT NOT NULL
)
