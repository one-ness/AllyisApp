﻿CREATE TABLE [Billing].[OrganizationBillingTokens]
(
    [TokenID] NCHAR(50) NOT NULL PRIMARY KEY,
		[OrgId] INT NOT NULL UNIQUE, 
    CONSTRAINT [FK_OrganizationBillingTokens_OrgId] FOREIGN KEY ([OrgId]) REFERENCES [Auth].[Organization](OrganizationId)

)
