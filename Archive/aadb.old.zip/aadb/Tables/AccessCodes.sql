﻿CREATE TABLE [dbo].[AccessCodes]
(
	[Code] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [OrgId] NVARCHAR(50) NOT NULL
)
